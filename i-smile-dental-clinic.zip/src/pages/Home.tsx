import React, { useState } from 'react';
import { Navbar } from '../components/common/Navbar';
import { HeroSection } from '../components/public/HeroSection';
import { TrustSection } from '../components/public/TrustSection';
import { ServicesSection } from '../components/public/ServicesSection';
import { AboutSection } from '../components/public/AboutSection';
import { PatientExperienceSection } from '../components/public/PatientExperienceSection';
import { HoursAndLocationSection } from '../components/public/HoursAndLocationSection';
import { BookingFlow } from '../components/public/booking/BookingFlow';
import { Footer } from '../components/common/Footer';
import { Service } from '../types/database';

export const Home: React.FC = () => {
  const [preSelectedService, setPreSelectedService] = useState<Service | null>(null);

  const scrollToBooking = () => {
    const el = document.getElementById('booking');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectServiceForBooking = (service: Service) => {
    setPreSelectedService(service);
    scrollToBooking();
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-800 font-sans selection:bg-teal-100 selection:text-teal-900">
      {/* Navigation */}
      <Navbar onBookClick={scrollToBooking} />

      {/* Main Landing Sections */}
      <main className="flex-1">
        <HeroSection onBookClick={scrollToBooking} />
        <TrustSection />
        <ServicesSection onSelectService={handleSelectServiceForBooking} />
        <AboutSection />
        <PatientExperienceSection />
        <HoursAndLocationSection />
        <BookingFlow
          preSelectedService={preSelectedService}
          onClearPreSelected={() => setPreSelectedService(null)}
        />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};
