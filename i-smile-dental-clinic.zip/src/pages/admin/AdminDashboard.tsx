import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useClinic } from '../../context/ClinicContext';
import { Appointment } from '../../types/database';
import { appointmentService } from '../../services/appointmentService';
import { AdminHeader } from '../../components/admin/AdminHeader';
import { OverviewMetrics } from '../../components/admin/OverviewMetrics';
import { AppointmentsManager } from '../../components/admin/AppointmentsManager';
import { ServicesManager } from '../../components/admin/ServicesManager';
import { BusinessHoursManager } from '../../components/admin/BusinessHoursManager';
import { BlockedDatesManager } from '../../components/admin/BlockedDatesManager';
import { ClinicSettingsManager } from '../../components/admin/ClinicSettingsManager';
import { isSupabaseConfigured } from '../../lib/supabase';
import { ShieldAlert, LogIn, Lock, Loader2, Database, Sparkles, ExternalLink } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { user, isAdmin, loading, adminCheckLoading, authError, signOut } = useAuth();
  const { settings, services, businessHours, blockedDates, refreshClinicData } = useClinic();

  const [activeTab, setActiveTab] = useState('overview');
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [appointmentsLoading, setAppointmentsLoading] = useState(false);
  const [appointmentsError, setAppointmentsError] = useState<string | null>(null);
  const [initialStatusFilter, setInitialStatusFilter] = useState<string>('all');
  const [refreshing, setRefreshing] = useState(false);

  // Fetch real appointments from Supabase
  const loadAppointments = useCallback(async () => {
    if (!isAdmin && isSupabaseConfigured) return;

    try {
      setAppointmentsLoading(true);
      setAppointmentsError(null);
      const data = await appointmentService.getAllAppointments('all');
      setAppointments(data);
    } catch (err: unknown) {
      console.warn('Unable to load appointments from Supabase:', err);
      const msg = err instanceof Error ? err.message : 'Error loading appointments';
      setAppointmentsError(msg);
    } finally {
      setAppointmentsLoading(false);
    }
  }, [isAdmin]);

  useEffect(() => {
    if (isAdmin || !isSupabaseConfigured) {
      loadAppointments();
    }
  }, [isAdmin, loadAppointments]);

  const handleRefreshAll = async () => {
    setRefreshing(true);
    await Promise.all([loadAppointments(), refreshClinicData()]);
    setRefreshing(false);
  };

  const handleNavigateToAppointments = (filter?: string) => {
    if (filter) setInitialStatusFilter(filter);
    setActiveTab('appointments');
  };

  // 1. Loading State: Checking session and admin authorization in admin_users
  if (loading || adminCheckLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-white">
        <Loader2 className="w-10 h-10 text-teal-400 animate-spin mb-4" />
        <h3 className="text-base font-bold text-white">Verifying Admin Access</h3>
        <p className="text-xs text-slate-400 mt-1">
          Querying Supabase Auth session &amp; verifying role against <code className="bg-slate-800 px-1 py-0.5 rounded font-mono">admin_users</code>...
        </p>
      </div>
    );
  }

  // 2. Not Authenticated State
  if (!user && isSupabaseConfigured) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-slate-900 rounded-3xl p-8 border border-slate-800 text-center shadow-2xl space-y-5">
          <div className="w-14 h-14 rounded-2xl bg-teal-500/10 text-teal-400 flex items-center justify-center mx-auto ring-8 ring-teal-500/5">
            <Lock className="w-7 h-7" />
          </div>

          <div>
            <h2 className="text-xl font-black text-white tracking-tight">Admin Authentication Required</h2>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Please sign in with your administrative credentials to access patient appointments, dental schedules, and clinic settings.
            </p>
          </div>

          <a
            href="/admin/login"
            className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-sm font-bold transition-colors shadow-lg cursor-pointer"
          >
            <LogIn className="w-4 h-4" />
            <span>Proceed to Admin Sign In</span>
          </a>

          <div className="pt-2 border-t border-slate-800">
            <a href="/" className="text-xs text-slate-500 hover:text-slate-300 transition-colors underline">
              Return to Public Website
            </a>
          </div>
        </div>
      </div>
    );
  }

  // 3. Authenticated BUT NOT in admin_users State (Strict Prompt Requirement #8)
  if (user && !isAdmin && isSupabaseConfigured) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="max-w-lg w-full bg-slate-900 rounded-3xl p-8 border border-amber-500/30 text-center shadow-2xl space-y-6">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto ring-8 ring-amber-500/5">
            <ShieldAlert className="w-7 h-7" />
          </div>

          <div className="space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400 block">
              Authorization Check Failed
            </span>
            <h2 className="text-xl font-black text-white">
              You are signed in, but you are not authorized as an admin.
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Authenticated user account (<span className="text-slate-200">{user.email}</span>) was not found in the{' '}
              <code className="bg-slate-800 text-amber-300 px-1 py-0.5 rounded font-mono">admin_users</code> table.
            </p>
          </div>

          {/* UID and Helper to add to admin_users */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-left text-xs space-y-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase">Your Supabase User ID (UUID):</span>
            <code className="block bg-slate-900 p-2 rounded text-teal-400 font-mono text-[11px] break-all select-all">
              {user.id}
            </code>
            <p className="text-[11px] text-slate-400">
              Run this SQL command in your Supabase project to grant admin access to this user:
            </p>
            <code className="block bg-slate-900 p-2 rounded text-slate-300 font-mono text-[11px] select-all">
              INSERT INTO public.admin_users (user_id) VALUES (&apos;{user.id}&apos;);
            </code>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <button
              onClick={() => signOut()}
              className="w-full sm:w-1/2 py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              Sign Out
            </button>
            <button
              onClick={() => handleRefreshAll()}
              className="w-full sm:w-1/2 py-2.5 px-4 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              Recheck Authorization
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 4. Authorized Admin Dashboard View
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans" id="admin-dashboard-root">
      {/* Header */}
      <AdminHeader
        activeTab={activeTab}
        onSelectTab={(tab) => setActiveTab(tab)}
        onRefresh={handleRefreshAll}
        refreshing={refreshing}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' && (
          <OverviewMetrics
            appointments={appointments}
            services={services}
            onGoToAppointments={handleNavigateToAppointments}
            onGoToServices={() => setActiveTab('services')}
          />
        )}

        {activeTab === 'appointments' && (
          <AppointmentsManager
            appointments={appointments}
            onRefresh={loadAppointments}
            initialFilter={initialStatusFilter}
          />
        )}

        {activeTab === 'services' && (
          <ServicesManager
            services={services}
            onRefresh={refreshClinicData}
          />
        )}

        {activeTab === 'schedule' && (
          <BusinessHoursManager
            businessHours={businessHours}
            clinicSettings={settings}
            onRefresh={refreshClinicData}
          />
        )}

        {activeTab === 'blocked-dates' && (
          <BlockedDatesManager
            blockedDates={blockedDates}
            onRefresh={refreshClinicData}
          />
        )}

        {activeTab === 'settings' && (
          <ClinicSettingsManager
            settings={settings}
            onRefresh={refreshClinicData}
          />
        )}
      </main>
    </div>
  );
};
