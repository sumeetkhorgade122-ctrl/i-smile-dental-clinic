import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ClinicProvider } from './context/ClinicContext';
import { SupabaseBanner } from './components/common/SupabaseBanner';
import { Home } from './pages/Home';
import { AdminLogin } from './pages/admin/AdminLogin';
import { AdminDashboard } from './pages/admin/AdminDashboard';

export default function App() {
  return (
    <AuthProvider>
      <ClinicProvider>
        <div className="min-h-screen flex flex-col bg-white font-sans antialiased text-slate-900">
          <SupabaseBanner />
          <BrowserRouter>
            <Routes>
              {/* Public Clinic Landing & Booking Page */}
              <Route path="/" element={<Home />} />

              {/* Admin Portal Authentication */}
              <Route path="/admin/login" element={<AdminLogin />} />

              {/* Admin Dashboard & Management */}
              <Route path="/admin/*" element={<AdminDashboard />} />

              {/* Fallback */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </BrowserRouter>
        </div>
      </ClinicProvider>
    </AuthProvider>
  );
}
