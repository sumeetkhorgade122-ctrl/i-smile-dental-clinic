/**
 * Date and Time utilities adhering strictly to Time Safety standards:
 * - Only formats validated real Date objects
 * - Correctly parses and combines YYYY-MM-DD + HH:mm
 * - Outputs clean Supabase-compatible dates (YYYY-MM-DD) and times (HH:mm:ss)
 */

export function formatDateToIso(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatTimeToIso(date: Date): string {
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${hours}:${minutes}:${seconds}`;
}

export function formatTimeForDisplay(date: Date): string {
  if (isNaN(date.getTime())) return '';
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true });
}

export function formatDateForDisplay(dateString: string): string {
  if (!dateString) return '';
  const [year, month, day] = dateString.split('-').map(Number);
  if (!year || !month || !day) return dateString;
  const d = new Date(year, month - 1, day);
  return d.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function formatTimeRangeForDisplay(startTime: string, endTime: string): string {
  const parseTimeString = (t: string): string => {
    if (!t) return '';
    const parts = t.split(':');
    const hours = parseInt(parts[0], 10);
    const minutes = parseInt(parts[1] || '0', 10);
    if (isNaN(hours)) return t;
    const dummyDate = new Date(2000, 0, 1, hours, minutes, 0);
    return formatTimeForDisplay(dummyDate);
  };
  return `${parseTimeString(startTime)} – ${parseTimeString(endTime)}`;
}

/**
 * Robustly parses a date string "YYYY-MM-DD" and a time string "HH:mm" or "HH:mm:ss"
 * and returns a guaranteed valid Date object in local timezone.
 */
export function combineDateAndTime(dateString: string, timeString: string): Date | null {
  if (!dateString || !timeString) return null;
  const [yearStr, monthStr, dayStr] = dateString.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10) - 1;
  const day = parseInt(dayStr, 10);

  const timeParts = timeString.split(':');
  const hours = parseInt(timeParts[0], 10);
  const minutes = parseInt(timeParts[1] || '0', 10);
  const seconds = parseInt(timeParts[2] || '0', 10);

  if (isNaN(year) || isNaN(month) || isNaN(day) || isNaN(hours) || isNaN(minutes)) {
    return null;
  }

  const d = new Date(year, month, day, hours, minutes, seconds);
  return isNaN(d.getTime()) ? null : d;
}

/**
 * Checks if two date strings match (YYYY-MM-DD)
 */
export function isSameDay(date1: string, date2: string): boolean {
  return date1 === date2;
}

/**
 * Gets day of week integer (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
 */
export function getDayOfWeek(dateString: string): number {
  const [year, month, day] = dateString.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  return d.getDay();
}
