import { Appointment, BlockedDate, BusinessHour, ClinicSettings, Service, TimeSlot } from '../types/database';
import { combineDateAndTime, formatTimeForDisplay, formatTimeToIso, getDayOfWeek } from './dateTime';

interface GenerateSlotsParams {
  selectedDate: string; // YYYY-MM-DD
  service: Service;
  clinicSettings: ClinicSettings;
  businessHours: BusinessHour[];
  blockedDates: BlockedDate[];
  existingAppointments: Appointment[];
  referenceNow?: Date; // For testing or current time check
}

export function isDateBlocked(selectedDate: string, blockedDates: BlockedDate[]): boolean {
  return blockedDates.some((b) => b.blocked_date === selectedDate);
}

export function isDateClosed(selectedDate: string, businessHours: BusinessHour[]): boolean {
  const dayOfWeek = getDayOfWeek(selectedDate);
  const hourConfig = businessHours.find((bh) => bh.weekday === dayOfWeek);
  if (!hourConfig) return true;
  return !hourConfig.is_open;
}

/**
 * Calculates real available time slots for a given date and service according to all rules.
 */
export function generateAvailableSlots({
  selectedDate,
  service,
  clinicSettings,
  businessHours,
  blockedDates,
  existingAppointments,
  referenceNow = new Date(),
}: GenerateSlotsParams): TimeSlot[] {
  // 1. Check if date is blocked
  if (isDateBlocked(selectedDate, blockedDates)) {
    return [];
  }

  // 2. Check if weekday is open
  const dayOfWeek = getDayOfWeek(selectedDate);
  const currentDayHours = businessHours.find((bh) => bh.weekday === dayOfWeek);
  if (!currentDayHours || !currentDayHours.is_open) {
    return [];
  }

  // 3. Parse working hours for the day
  const dayStart = combineDateAndTime(selectedDate, currentDayHours.start_time);
  const dayEnd = combineDateAndTime(selectedDate, currentDayHours.end_time);
  if (!dayStart || !dayEnd || dayStart >= dayEnd) {
    return [];
  }

  const durationMs = service.duration_minutes * 60 * 1000;
  const intervalMinutes = Math.max(15, clinicSettings.slot_interval_minutes || 30);
  const intervalMs = intervalMinutes * 60 * 1000;
  const noticeHours = clinicSettings.booking_notice_hours || 0;
  const minimumBookingTime = new Date(referenceNow.getTime() + noticeHours * 60 * 60 * 1000);

  // Filter active, non-cancelled appointments for this date
  const activeExistingAppts = existingAppointments.filter((appt) => {
    if (appt.status === 'cancelled') return false;
    return appt.appointment_date === selectedDate;
  });

  // Map existing appointments to parsed Date start & end ranges
  const bookedRanges: { start: Date; end: Date }[] = [];
  for (const appt of activeExistingAppts) {
    const aStart = combineDateAndTime(appt.appointment_date, appt.start_time);
    const aEnd = combineDateAndTime(appt.appointment_date, appt.end_time);
    if (aStart && aEnd) {
      bookedRanges.push({ start: aStart, end: aEnd });
    }
  }

  const availableSlots: TimeSlot[] = [];

  // Generate potential slots from dayStart to dayEnd
  let currentSlotStart = new Date(dayStart.getTime());

  while (currentSlotStart.getTime() + durationMs <= dayEnd.getTime()) {
    const currentSlotEnd = new Date(currentSlotStart.getTime() + durationMs);

    // Rule 6: Respect booking notice time
    const meetsNotice = currentSlotStart.getTime() >= minimumBookingTime.getTime();

    // Rule 4: Overlap rule
    // new_start < existing_end AND new_end > existing_start
    const hasConflict = bookedRanges.some((booked) => {
      return (
        currentSlotStart.getTime() < booked.end.getTime() &&
        currentSlotEnd.getTime() > booked.start.getTime()
      );
    });

    if (meetsNotice && !hasConflict) {
      availableSlots.push({
        start: currentSlotStart,
        end: currentSlotEnd,
        label: formatTimeForDisplay(currentSlotStart),
        formattedStartTime: formatTimeToIso(currentSlotStart),
        formattedEndTime: formatTimeToIso(currentSlotEnd),
      });
    }

    // Step to the next interval
    currentSlotStart = new Date(currentSlotStart.getTime() + intervalMs);
  }

  return availableSlots;
}
