import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  isAdmin: boolean;
  loading: boolean;
  adminCheckLoading: boolean;
  authError: string | null;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  checkAdminAccess: (userId: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [adminCheckLoading, setAdminCheckLoading] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Strict check: admin_users.user_id = user.id
  const checkAdminAccess = async (userId: string): Promise<boolean> => {
    if (!isSupabaseConfigured) {
      setIsAdmin(false);
      return false;
    }

    try {
      setAdminCheckLoading(true);
      const { data, error } = await supabase
        .from('admin_users')
        .select('id, user_id')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) {
        console.error('Error checking admin_users in Supabase:', error.message);
        setIsAdmin(false);
        setAuthError('Error checking admin authorization status.');
        return false;
      }

      if (data && data.user_id === userId) {
        setIsAdmin(true);
        setAuthError(null);
        return true;
      } else {
        setIsAdmin(false);
        setAuthError('You are signed in, but you are not authorized as an admin.');
        return false;
      }
    } catch (err) {
      console.error('Unexpected error checking admin status:', err);
      setIsAdmin(false);
      setAuthError('An error occurred during admin authorization check.');
      return false;
    } finally {
      setAdminCheckLoading(false);
    }
  };

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }

    let isMounted = true;

    // Check existing session on mount
    supabase.auth
      .getSession()
      .then(async ({ data: { session } }) => {
        if (!isMounted) return;
        setSession(session);
        setUser(session?.user ?? null);

        if (session?.user) {
          await checkAdminAccess(session.user.id);
        } else {
          setIsAdmin(false);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.warn('Unable to fetch Supabase auth session:', err);
        if (!isMounted) return;
        setSession(null);
        setUser(null);
        setIsAdmin(false);
        setLoading(false);
      });

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        if (!isMounted) return;
        setSession(session);
        setUser(session?.user ?? null);

        if (session?.user) {
          await checkAdminAccess(session.user.id);
        } else {
          setIsAdmin(false);
          setAuthError(null);
        }
        setLoading(false);
      }
    );

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    if (!isSupabaseConfigured) {
      return {
        success: false,
        error: 'Supabase credentials are not configured. Please add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your environment.',
      };
    }

    try {
      setAuthError(null);
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        setAuthError(error.message);
        return { success: false, error: error.message };
      }

      if (!data.user) {
        setAuthError('Authentication succeeded but user record is missing.');
        return { success: false, error: 'User record missing' };
      }

      // Perform strict check against admin_users.user_id = user.id
      const authorized = await checkAdminAccess(data.user.id);
      if (!authorized) {
        return {
          success: false,
          error: 'You are signed in, but you are not authorized as an admin.',
        };
      }

      return { success: true };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unexpected error during sign in';
      setAuthError(msg);
      return { success: false, error: msg };
    }
  };

  const signOut = async () => {
    if (isSupabaseConfigured) {
      await supabase.auth.signOut();
    }
    setUser(null);
    setSession(null);
    setIsAdmin(false);
    setAuthError(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        isAdmin,
        loading,
        adminCheckLoading,
        authError,
        signIn,
        signOut,
        checkAdminAccess,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
