import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { BusinessHour, BlockedDate, ClinicSettings, Service } from '../types/database';
import { clinicService } from '../services/clinicService';
import { defaultBusinessHours, defaultClinicSettings, defaultServices } from '../data/defaultData';

interface ClinicContextType {
  settings: ClinicSettings;
  services: Service[];
  activeServices: Service[];
  businessHours: BusinessHour[];
  blockedDates: BlockedDate[];
  loading: boolean;
  error: string | null;
  refreshClinicData: () => Promise<void>;
  updateSettingsState: (updated: ClinicSettings) => void;
  updateBusinessHoursState: (hours: BusinessHour[]) => void;
  updateServicesState: (services: Service[]) => void;
  updateBlockedDatesState: (dates: BlockedDate[]) => void;
}

const ClinicContext = createContext<ClinicContextType | undefined>(undefined);

export const ClinicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<ClinicSettings>(defaultClinicSettings);
  const [services, setServices] = useState<Service[]>(defaultServices);
  const [businessHours, setBusinessHours] = useState<BusinessHour[]>(defaultBusinessHours);
  const [blockedDates, setBlockedDates] = useState<BlockedDate[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAllData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const [fetchedSettings, fetchedServices, fetchedHours, fetchedBlocked] = await Promise.all([
        clinicService.getClinicSettings(),
        clinicService.getAllServices(),
        clinicService.getBusinessHours(),
        clinicService.getBlockedDates(),
      ]);

      setSettings(fetchedSettings);
      setServices(fetchedServices);
      setBusinessHours(fetchedHours);
      setBlockedDates(fetchedBlocked);
    } catch (err: unknown) {
      console.error('Error fetching clinic data:', err);
      const msg = err instanceof Error ? err.message : 'Unable to load clinic details';
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  const activeServices = services.filter((s) => s.is_active);

  const updateSettingsState = (updated: ClinicSettings) => setSettings(updated);
  const updateBusinessHoursState = (hours: BusinessHour[]) => setBusinessHours(hours);
  const updateServicesState = (newServices: Service[]) => setServices(newServices);
  const updateBlockedDatesState = (dates: BlockedDate[]) => setBlockedDates(dates);

  return (
    <ClinicContext.Provider
      value={{
        settings,
        services,
        activeServices,
        businessHours,
        blockedDates,
        loading,
        error,
        refreshClinicData: fetchAllData,
        updateSettingsState,
        updateBusinessHoursState,
        updateServicesState,
        updateBlockedDatesState,
      }}
    >
      {children}
    </ClinicContext.Provider>
  );
};

export const useClinic = (): ClinicContextType => {
  const context = useContext(ClinicContext);
  if (!context) {
    throw new Error('useClinic must be used within a ClinicProvider');
  }
  return context;
};
