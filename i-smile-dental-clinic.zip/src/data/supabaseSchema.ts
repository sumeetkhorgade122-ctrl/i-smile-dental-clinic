export const SUPABASE_SQL_SCHEMA = `-- ================================================================
-- I SMILE DENTAL CLINIC - COMPLETE SUPABASE DATABASE SETUP SCRIPT
-- Run this in your Supabase SQL Editor (Database -> SQL Editor)
-- ================================================================

-- 1. Services table
CREATE TABLE IF NOT EXISTS public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  duration_minutes INTEGER NOT NULL DEFAULT 45,
  price NUMERIC(10,2) NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 2. Appointments table
CREATE TABLE IF NOT EXISTS public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  service_id UUID REFERENCES public.services(id) ON DELETE SET NULL,
  appointment_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. Business hours table
CREATE TABLE IF NOT EXISTS public.business_hours (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  weekday INTEGER NOT NULL, -- 0=Sunday, 1=Monday, 2=Tuesday, 3=Wednesday, 4=Thursday, 5=Friday, 6=Saturday
  is_open BOOLEAN NOT NULL DEFAULT true,
  start_time TIME NOT NULL DEFAULT '09:00:00',
  end_time TIME NOT NULL DEFAULT '18:00:00'
);

-- 4. Blocked dates table
CREATE TABLE IF NOT EXISTS public.blocked_dates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  blocked_date DATE NOT NULL,
  reason TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 5. Clinic settings table
CREATE TABLE IF NOT EXISTS public.clinic_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_name TEXT NOT NULL DEFAULT 'I Smile Dental Clinic',
  clinic_email TEXT NOT NULL DEFAULT 'care@ismileclinic.com',
  clinic_phone TEXT NOT NULL DEFAULT '+1 (555) 345-7890',
  clinic_address TEXT NOT NULL DEFAULT '742 Evergreen Medical Park, Suite 300, New York, NY 10001',
  slot_interval_minutes INTEGER NOT NULL DEFAULT 30,
  booking_notice_hours INTEGER NOT NULL DEFAULT 2,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6. Admin users table
CREATE TABLE IF NOT EXISTS public.admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_hours ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocked_dates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clinic_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

-- Public RLS Policies
DROP POLICY IF EXISTS "Public read active services" ON public.services;
CREATE POLICY "Public read active services" ON public.services FOR SELECT USING (true);

DROP POLICY IF EXISTS "Public read business hours" ON public.business_hours;
CREATE POLICY "Public read business hours" ON public.business_hours FOR SELECT USING (true);

DROP POLICY IF EXISTS "Public read blocked dates" ON public.blocked_dates;
CREATE POLICY "Public read blocked dates" ON public.blocked_dates FOR SELECT USING (true);

DROP POLICY IF EXISTS "Public read clinic settings" ON public.clinic_settings;
CREATE POLICY "Public read clinic settings" ON public.clinic_settings FOR SELECT USING (true);

DROP POLICY IF EXISTS "Public insert appointments" ON public.appointments;
CREATE POLICY "Public insert appointments" ON public.appointments FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Public select appointments for availability" ON public.appointments;
CREATE POLICY "Public select appointments for availability" ON public.appointments FOR SELECT USING (true);

-- Admin RLS Policies (Full access to all tables for authorized admins)
DROP POLICY IF EXISTS "Admin full access services" ON public.services;
CREATE POLICY "Admin full access services" ON public.services FOR ALL 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

DROP POLICY IF EXISTS "Admin full access appointments" ON public.appointments;
CREATE POLICY "Admin full access appointments" ON public.appointments FOR ALL 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

DROP POLICY IF EXISTS "Admin full access business hours" ON public.business_hours;
CREATE POLICY "Admin full access business hours" ON public.business_hours FOR ALL 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

DROP POLICY IF EXISTS "Admin full access blocked dates" ON public.blocked_dates;
CREATE POLICY "Admin full access blocked dates" ON public.blocked_dates FOR ALL 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

DROP POLICY IF EXISTS "Admin full access clinic settings" ON public.clinic_settings;
CREATE POLICY "Admin full access clinic settings" ON public.clinic_settings FOR ALL 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

DROP POLICY IF EXISTS "Admin read admin_users" ON public.admin_users;
CREATE POLICY "Admin read admin_users" ON public.admin_users FOR SELECT 
USING (auth.uid() = user_id OR auth.uid() IN (SELECT user_id FROM public.admin_users));

-- SEED DATA
-- Insert default clinic settings if empty
INSERT INTO public.clinic_settings (clinic_name, clinic_email, clinic_phone, clinic_address, slot_interval_minutes, booking_notice_hours)
SELECT 'I Smile Dental Clinic', 'care@ismileclinic.com', '+1 (555) 345-7890', '742 Evergreen Medical Park, Suite 300, New York, NY 10001', 30, 2
WHERE NOT EXISTS (SELECT 1 FROM public.clinic_settings);

-- Insert default business hours if empty
INSERT INTO public.business_hours (weekday, is_open, start_time, end_time)
SELECT d.weekday, d.is_open, d.start_time::time, d.end_time::time
FROM (VALUES 
  (1, true, '09:00:00', '18:00:00'),
  (2, true, '09:00:00', '18:00:00'),
  (3, true, '09:00:00', '18:00:00'),
  (4, true, '09:00:00', '18:00:00'),
  (5, true, '09:00:00', '17:00:00'),
  (6, true, '10:00:00', '15:00:00'),
  (0, false, '09:00:00', '18:00:00')
) AS d(weekday, is_open, start_time, end_time)
WHERE NOT EXISTS (SELECT 1 FROM public.business_hours);

-- Insert default services if empty
INSERT INTO public.services (name, description, duration_minutes, price, is_active)
SELECT s.name, s.description, s.duration_minutes, s.price, s.is_active
FROM (VALUES
  ('Comprehensive Dental Examination', 'Complete oral health assessment including digital low-radiation diagnostics, periodontal charting, and personalized smile consultation.', 45, 95.00, true),
  ('Advanced Ultrasonic Teeth Cleaning', 'Gentle plaque and calculus removal with ultrasonic scaling, stain polishing, and remineralizing fluoride application.', 45, 120.00, true),
  ('Professional Laser Smile Whitening', 'In-office clinical teeth whitening delivering up to 8 shades brighter in a single comfortable session with enamel-safe formula.', 60, 280.00, true),
  ('Biomimetic Tooth-Colored Restoration', 'High-strength composite resin filling matched seamlessly to your natural tooth shade, restoring strength and aesthetics.', 45, 160.00, true),
  ('Urgent Dental Care Consultation', 'Priority evaluation and pain relief for dental emergencies, chipped teeth, sudden toothaches, or oral trauma.', 30, 110.00, true),
  ('Cosmetic Smile Design & Veneer Consultation', 'Comprehensive aesthetic evaluation with digital smile simulation to plan porcelain veneers, bonding, or smile enhancements.', 45, 150.00, true)
) AS s(name, description, duration_minutes, price, is_active)
WHERE NOT EXISTS (SELECT 1 FROM public.services);
`;
