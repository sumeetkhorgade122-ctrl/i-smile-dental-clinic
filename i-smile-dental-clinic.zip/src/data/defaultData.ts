import { Service, BusinessHour, ClinicSettings } from '../types/database';

export const defaultClinicSettings: ClinicSettings = {
  id: 'clinic-default',
  clinic_name: 'I Smile Dental Clinic',
  clinic_email: 'care@ismileclinic.com',
  clinic_phone: '+1 (555) 345-7890',
  clinic_address: '742 Evergreen Medical Park, Suite 300, New York, NY 10001',
  slot_interval_minutes: 30,
  booking_notice_hours: 2,
  created_at: new Date().toISOString(),
};

export const defaultBusinessHours: BusinessHour[] = [
  { id: 'bh-1', weekday: 1, is_open: true, start_time: '09:00:00', end_time: '18:00:00' }, // Monday
  { id: 'bh-2', weekday: 2, is_open: true, start_time: '09:00:00', end_time: '18:00:00' }, // Tuesday
  { id: 'bh-3', weekday: 3, is_open: true, start_time: '09:00:00', end_time: '18:00:00' }, // Wednesday
  { id: 'bh-4', weekday: 4, is_open: true, start_time: '09:00:00', end_time: '18:00:00' }, // Thursday
  { id: 'bh-5', weekday: 5, is_open: true, start_time: '09:00:00', end_time: '17:00:00' }, // Friday
  { id: 'bh-6', weekday: 6, is_open: true, start_time: '10:00:00', end_time: '15:00:00' }, // Saturday
  { id: 'bh-0', weekday: 0, is_open: false, start_time: '09:00:00', end_time: '18:00:00' }, // Sunday
];

export const defaultServices: Service[] = [
  {
    id: 'srv-1',
    name: 'Comprehensive Dental Examination',
    description: 'Complete oral health assessment including digital low-radiation diagnostics, periodontal charting, and personalized smile consultation.',
    duration_minutes: 45,
    price: 95.0,
    is_active: true,
  },
  {
    id: 'srv-2',
    name: 'Advanced Ultrasonic Teeth Cleaning',
    description: 'Gentle plaque and calculus removal with ultrasonic scaling, stain polishing, and remineralizing fluoride application for lasting fresh breath.',
    duration_minutes: 45,
    price: 120.0,
    is_active: true,
  },
  {
    id: 'srv-3',
    name: 'Professional Laser Smile Whitening',
    description: 'In-office clinical teeth whitening delivering up to 8 shades brighter in a single comfortable session with enamel-safe formula.',
    duration_minutes: 60,
    price: 280.0,
    is_active: true,
  },
  {
    id: 'srv-4',
    name: 'Biomimetic Tooth-Colored Restoration',
    description: 'High-strength composite resin filling matched seamlessly to your natural tooth shade, restoring strength and natural tooth anatomy.',
    duration_minutes: 45,
    price: 160.0,
    is_active: true,
  },
  {
    id: 'srv-5',
    name: 'Urgent Dental Care Consultation',
    description: 'Priority evaluation and pain relief for dental emergencies, chipped teeth, sudden toothaches, or oral trauma.',
    duration_minutes: 30,
    price: 110.0,
    is_active: true,
  },
  {
    id: 'srv-6',
    name: 'Cosmetic Smile Design & Veneer Consultation',
    description: 'Comprehensive aesthetic evaluation with digital smile simulation to plan porcelain veneers, bonding, or smile enhancements.',
    duration_minutes: 45,
    price: 150.0,
    is_active: true,
  },
];

export const weekdayNames = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];
