export interface ClinicImageItem {
  url: string;
  alt: string;
}

export const clinicImages = {
  hero: {
    url: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1600&q=80',
    alt: 'Modern, brightly lit dental clinic suite with ergonomic treatment chair and natural daylight',
  },
  about: {
    url: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=1200&q=80',
    alt: 'Friendly female dentist consulting closely with patient in modern treatment room',
  },
  team: {
    url: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=1200&q=80',
    alt: 'Warm, welcoming dental clinic reception area and patient care lounge',
  },
  dentistInAction: {
    url: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&w=1200&q=80',
    alt: 'Dentist conducting a gentle, precision dental examination using modern diagnostic tools',
  },
  services: {
    checkup: {
      url: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=800&q=80',
      alt: 'Dentist conducting thorough checkup and oral health consultation with digital screen',
    },
    cleaning: {
      url: 'https://images.unsplash.com/photo-1598256989800-fe5f95da9787?auto=format&fit=crop&w=800&q=80',
      alt: 'Clean sterilized dental equipment and ultrasonic teeth cleaning instruments',
    },
    whitening: {
      url: 'https://images.unsplash.com/photo-1609840114035-3c981b782dfe?auto=format&fit=crop&w=800&q=80',
      alt: 'Radiant healthy white smile showing confidence and excellent oral care',
    },
    filling: {
      url: 'https://images.unsplash.com/photo-1606811971618-4486d14f3f99?auto=format&fit=crop&w=800&q=80',
      alt: 'Modern biomimetic restorative dentistry and precision tooth-colored filling procedure',
    },
    emergency: {
      url: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80',
      alt: 'Caring doctor providing urgent dental consultation and pain relief',
    },
    cosmetic: {
      url: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=800&q=80',
      alt: 'Cosmetic smile makeover consultation planning veneers and smile aesthetics',
    },
  },
  facility: {
    url: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&w=1200&q=80',
    alt: 'Sterilization station and state-of-the-art medical grade dental laboratory',
  },
};

export function getServiceImage(serviceName: string): ClinicImageItem {
  const normalized = serviceName.toLowerCase();
  if (normalized.includes('checkup') || normalized.includes('examination') || normalized.includes('consult')) {
    return clinicImages.services.checkup;
  }
  if (normalized.includes('clean') || normalized.includes('hygiene') || normalized.includes('prophylaxis')) {
    return clinicImages.services.cleaning;
  }
  if (normalized.includes('whiten') || normalized.includes('bleach')) {
    return clinicImages.services.whitening;
  }
  if (normalized.includes('fill') || normalized.includes('restor') || normalized.includes('cavity') || normalized.includes('decay')) {
    return clinicImages.services.filling;
  }
  if (normalized.includes('emergenc') || normalized.includes('urgent') || normalized.includes('pain') || normalized.includes('trauma')) {
    return clinicImages.services.emergency;
  }
  if (normalized.includes('cosmetic') || normalized.includes('veneer') || normalized.includes('aesthetic') || normalized.includes('invisalign') || normalized.includes('brace')) {
    return clinicImages.services.cosmetic;
  }
  return clinicImages.services.checkup;
}
