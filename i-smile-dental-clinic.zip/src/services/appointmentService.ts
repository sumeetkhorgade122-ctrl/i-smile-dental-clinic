import { supabase, isSupabaseConfigured, isNetworkFetchError } from '../lib/supabase';
import { Appointment, AppointmentStatus } from '../types/database';
import { defaultServices } from '../data/defaultData';

const LOCAL_APPOINTMENTS_KEY = 'ismile_local_appointments';
const UUID_REGEX =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

const readLocalAppointments = (): Appointment[] => {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(LOCAL_APPOINTMENTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as Appointment[]) : [];
  } catch {
    return [];
  }
};

const writeLocalAppointments = (appointments: Appointment[]): void => {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(LOCAL_APPOINTMENTS_KEY, JSON.stringify(appointments));
  } catch {
    // Ignore storage quota or iframe restrictions
  }
};

const saveLocalAppointment = (appointmentData: {
  full_name: string;
  email: string;
  phone: string;
  service_id: string;
  appointment_date: string;
  start_time: string;
  end_time: string;
  notes?: string;
}): Appointment => {
  const matchedService = defaultServices.find((s) => s.id === appointmentData.service_id);
  const localAppt: Appointment = {
    id: `local-appt-${Date.now()}`,
    full_name: appointmentData.full_name,
    email: appointmentData.email,
    phone: appointmentData.phone,
    service_id: appointmentData.service_id,
    appointment_date: appointmentData.appointment_date,
    start_time: appointmentData.start_time,
    end_time: appointmentData.end_time,
    status: 'pending',
    notes: appointmentData.notes || null,
    created_at: new Date().toISOString(),
    service: matchedService,
  };

  const existing = readLocalAppointments();
  writeLocalAppointments([...existing, localAppt]);
  return localAppt;
};

const getLocalAppointmentsForDate = (dateString: string): Appointment[] => {
  return readLocalAppointments().filter(
    (appt) => appt.appointment_date === dateString && appt.status !== 'cancelled'
  );
};

export const appointmentService = {
  // 1. Fetch appointments for a specific date (used by public booking availability check)
  async getAppointmentsForDate(dateString: string): Promise<Appointment[]> {
    if (!isSupabaseConfigured) {
      return getLocalAppointmentsForDate(dateString);
    }

    try {
      const { data, error } = await supabase
        .from('appointments')
        .select(
          'id, full_name, email, phone, service_id, appointment_date, start_time, end_time, status, notes, created_at'
        )
        .eq('appointment_date', dateString)
        .neq('status', 'cancelled');

      if (error) {
        console.warn('Error fetching appointments for date from Supabase:', error.message);
        return getLocalAppointmentsForDate(dateString);
      }
      return (data as Appointment[]) || [];
    } catch (err: unknown) {
      console.warn('Network error fetching appointments for date, using local records:', err);
      return getLocalAppointmentsForDate(dateString);
    }
  },

  // 2. Fetch all appointments (for Admin dashboard)
  async getAllAppointments(filterStatus?: AppointmentStatus | 'all'): Promise<Appointment[]> {
    const getFilteredLocal = () => {
      const local = readLocalAppointments().map((appt) => ({
        ...appt,
        service:
          appt.service || defaultServices.find((s) => s.id === appt.service_id),
      }));
      if (filterStatus && filterStatus !== 'all') {
        return local.filter((a) => a.status === filterStatus);
      }
      return local;
    };

    if (!isSupabaseConfigured) {
      return getFilteredLocal();
    }

    try {
      let query = supabase
        .from('appointments')
        .select(`
          id,
          full_name,
          email,
          phone,
          service_id,
          appointment_date,
          start_time,
          end_time,
          status,
          notes,
          created_at,
          service:services(id, name, duration_minutes, price)
        `)
        .order('appointment_date', { ascending: true })
        .order('start_time', { ascending: true });

      if (filterStatus && filterStatus !== 'all') {
        query = query.eq('status', filterStatus);
      }

      const { data, error } = await query;

      if (error) {
        if (isNetworkFetchError(error)) {
          console.warn('Supabase unreachable while loading appointments, using local records.');
          return getFilteredLocal();
        }
        console.warn('Error fetching appointments from Supabase:', error.message);
        throw new Error(`Unable to load appointments: ${error.message}`);
      }

      // Map nested service object safely
      return (data || []).map((row: any) => ({
        ...row,
        service: Array.isArray(row.service) ? row.service[0] : row.service,
      })) as Appointment[];
    } catch (err: unknown) {
      if (isNetworkFetchError(err)) {
        console.warn('Network error loading appointments, using local records.');
        return getFilteredLocal();
      }
      throw err;
    }
  },

  // 3. Create appointment (Public booking submission)
  async createAppointment(appointmentData: {
    full_name: string;
    email: string;
    phone: string;
    service_id: string;
    appointment_date: string;
    start_time: string;
    end_time: string;
    notes?: string;
  }): Promise<Appointment> {
    // Double check availability to prevent race condition overlaps
    const existing = await this.getAppointmentsForDate(appointmentData.appointment_date);
    const newStart = appointmentData.start_time;
    const newEnd = appointmentData.end_time;

    const conflict = existing.some((appt) => {
      if (appt.status === 'cancelled') return false;
      return newStart < appt.end_time && newEnd > appt.start_time;
    });

    if (conflict) {
      throw new Error('This time slot is no longer available. Please choose another time.');
    }

    if (!isSupabaseConfigured) {
      return saveLocalAppointment(appointmentData);
    }

    // Ensure service_id is a valid UUID when targeting Postgres UUID column
    const dbServiceId = UUID_REGEX.test(appointmentData.service_id)
      ? appointmentData.service_id
      : null;

    try {
      const { data, error } = await supabase
        .from('appointments')
        .insert([
          {
            full_name: appointmentData.full_name,
            email: appointmentData.email,
            phone: appointmentData.phone,
            service_id: dbServiceId,
            appointment_date: appointmentData.appointment_date,
            start_time: appointmentData.start_time,
            end_time: appointmentData.end_time,
            status: 'pending',
            notes: appointmentData.notes || null,
          },
        ])
        .select()
        .single();

      if (error) {
        if (isNetworkFetchError(error)) {
          console.warn(
            'Supabase unreachable while saving appointment, saved to local fallback storage:',
            error.message
          );
          return saveLocalAppointment(appointmentData);
        }
        console.warn('Error inserting appointment in Supabase:', error.message);
        throw new Error(`Your appointment could not be submitted: ${error.message}`);
      }

      return data as Appointment;
    } catch (err: unknown) {
      if (isNetworkFetchError(err)) {
        console.warn(
          'Network fetch error while saving appointment, saved to local fallback storage.'
        );
        return saveLocalAppointment(appointmentData);
      }
      throw err;
    }
  },

  // 4. Update appointment status (Admin action)
  async updateAppointmentStatus(id: string, status: AppointmentStatus): Promise<void> {
    const updateLocal = () => {
      const list = readLocalAppointments();
      const updated = list.map((appt) => (appt.id === id ? { ...appt, status } : appt));
      writeLocalAppointments(updated);
    };

    if (!isSupabaseConfigured || id.startsWith('local-appt-')) {
      updateLocal();
      return;
    }

    try {
      const { error } = await supabase
        .from('appointments')
        .update({ status })
        .eq('id', id);

      if (error) {
        if (isNetworkFetchError(error)) {
          console.warn('Supabase unreachable while updating status, updated locally.');
          updateLocal();
          return;
        }
        console.warn('Error updating appointment status:', error.message);
        throw new Error(`Unable to update appointment status: ${error.message}`);
      }
    } catch (err: unknown) {
      if (isNetworkFetchError(err)) {
        updateLocal();
        return;
      }
      throw err;
    }
  },
};
