import { supabase, isSupabaseConfigured, isNetworkFetchError } from '../lib/supabase';
import { Service, BusinessHour, BlockedDate, ClinicSettings } from '../types/database';
import { defaultBusinessHours, defaultClinicSettings, defaultServices } from '../data/defaultData';

export const clinicService = {
  // 1. SERVICES
  async getActiveServices(): Promise<Service[]> {
    if (!isSupabaseConfigured) {
      return defaultServices.filter((s) => s.is_active);
    }
    try {
      const { data, error } = await supabase
        .from('services')
        .select('*')
        .eq('is_active', true)
        .order('price', { ascending: true });

      if (error || !data || data.length === 0) {
        if (error) {
          console.warn('Error fetching active services from Supabase, using defaults:', error.message);
        }
        return defaultServices.filter((s) => s.is_active);
      }
      return data as Service[];
    } catch (err) {
      console.warn('Network error fetching active services, using defaults:', err);
      return defaultServices.filter((s) => s.is_active);
    }
  },

  async getAllServices(): Promise<Service[]> {
    if (!isSupabaseConfigured) {
      return defaultServices;
    }
    try {
      const { data, error } = await supabase
        .from('services')
        .select('*')
        .order('created_at', { ascending: false });

      if (error || !data || data.length === 0) {
        if (error) {
          console.warn('Error fetching all services from Supabase:', error.message);
        }
        return defaultServices;
      }
      return data as Service[];
    } catch (err) {
      console.warn('Network error fetching services, using defaults:', err);
      return defaultServices;
    }
  },

  async createService(serviceData: Omit<Service, 'id' | 'created_at'>): Promise<Service> {
    if (!isSupabaseConfigured) {
      const newService: Service = {
        ...serviceData,
        id: `srv-${Date.now()}`,
        created_at: new Date().toISOString(),
      };
      return newService;
    }

    const { data, error } = await supabase
      .from('services')
      .insert([serviceData])
      .select()
      .single();

    if (error) {
      throw new Error(`Unable to save service: ${error.message}`);
    }
    return data as Service;
  },

  async updateService(id: string, updates: Partial<Service>): Promise<Service> {
    if (!isSupabaseConfigured) {
      return { ...defaultServices[0], ...updates, id };
    }

    const { data, error } = await supabase
      .from('services')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      throw new Error(`Unable to update service: ${error.message}`);
    }
    return data as Service;
  },

  // 2. CLINIC SETTINGS
  async getClinicSettings(): Promise<ClinicSettings> {
    if (!isSupabaseConfigured) {
      return defaultClinicSettings;
    }

    try {
      const { data, error } = await supabase
        .from('clinic_settings')
        .select('*')
        .limit(1)
        .maybeSingle();

      if (error || !data) {
        if (error) {
          console.warn('Using default clinic settings:', error.message);
        }
        return defaultClinicSettings;
      }
      return data as ClinicSettings;
    } catch (err) {
      console.warn('Network error loading clinic settings, using defaults:', err);
      return defaultClinicSettings;
    }
  },

  async updateClinicSettings(id: string, updates: Partial<ClinicSettings>): Promise<ClinicSettings> {
    if (!isSupabaseConfigured) {
      return { ...defaultClinicSettings, ...updates };
    }

    const { data, error } = await supabase
      .from('clinic_settings')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      throw new Error(`Unable to save clinic settings: ${error.message}`);
    }
    return data as ClinicSettings;
  },

  // 3. BUSINESS HOURS
  async getBusinessHours(): Promise<BusinessHour[]> {
    if (!isSupabaseConfigured) {
      return defaultBusinessHours;
    }

    try {
      const { data, error } = await supabase
        .from('business_hours')
        .select('*')
        .order('weekday', { ascending: true });

      if (error || !data || data.length === 0) {
        if (error) {
          console.warn('Using default business hours:', error.message);
        }
        return defaultBusinessHours;
      }
      return data as BusinessHour[];
    } catch (err) {
      console.warn('Network error loading business hours, using defaults:', err);
      return defaultBusinessHours;
    }
  },

  async updateBusinessHour(id: string, updates: Partial<BusinessHour>): Promise<BusinessHour> {
    if (!isSupabaseConfigured) {
      const found = defaultBusinessHours.find((b) => b.id === id) || defaultBusinessHours[0];
      return { ...found, ...updates };
    }

    const { data, error } = await supabase
      .from('business_hours')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      throw new Error(`Unable to update business hours: ${error.message}`);
    }
    return data as BusinessHour;
  },

  // 4. BLOCKED DATES
  async getBlockedDates(): Promise<BlockedDate[]> {
    if (!isSupabaseConfigured) {
      return [];
    }

    try {
      const { data, error } = await supabase
        .from('blocked_dates')
        .select('*')
        .order('blocked_date', { ascending: true });

      if (error) {
        console.warn('Error loading blocked dates:', error.message);
        return [];
      }
      return (data as BlockedDate[]) || [];
    } catch (err) {
      console.warn('Network error loading blocked dates:', err);
      return [];
    }
  },

  async addBlockedDate(blockedDate: string, reason: string): Promise<BlockedDate> {
    if (!isSupabaseConfigured) {
      return {
        id: `blk-${Date.now()}`,
        blocked_date: blockedDate,
        reason,
        created_at: new Date().toISOString(),
      };
    }

    const { data, error } = await supabase
      .from('blocked_dates')
      .insert([{ blocked_date: blockedDate, reason }])
      .select()
      .single();

    if (error) {
      throw new Error(`Unable to block date: ${error.message}`);
    }
    return data as BlockedDate;
  },

  async deleteBlockedDate(id: string): Promise<void> {
    if (!isSupabaseConfigured) return;

    const { error } = await supabase
      .from('blocked_dates')
      .delete()
      .eq('id', id);

    if (error) {
      throw new Error(`Unable to remove blocked date: ${error.message}`);
    }
  },

  // 5. SEED INITIAL DATA TO SUPABASE IF EMPTY
  async seedInitialData(): Promise<{ success: boolean; message: string }> {
    if (!isSupabaseConfigured) {
      return { success: false, message: 'Supabase credentials not configured yet in environment.' };
    }

    try {
      // Check if clinic_settings exists
      const { data: existingSettings, error: settingsErr } = await supabase
        .from('clinic_settings')
        .select('id')
        .limit(1);
      if (settingsErr) {
        if (isNetworkFetchError(settingsErr)) {
          return {
            success: false,
            message: 'Unable to reach Supabase. Check your Project URL and make sure your project is active.',
          };
        }
        return { success: false, message: settingsErr.message };
      }

      if (!existingSettings || existingSettings.length === 0) {
        const { error } = await supabase.from('clinic_settings').insert([
          {
            clinic_name: defaultClinicSettings.clinic_name,
            clinic_email: defaultClinicSettings.clinic_email,
            clinic_phone: defaultClinicSettings.clinic_phone,
            clinic_address: defaultClinicSettings.clinic_address,
            slot_interval_minutes: defaultClinicSettings.slot_interval_minutes,
            booking_notice_hours: defaultClinicSettings.booking_notice_hours,
          },
        ]);
        if (error) return { success: false, message: error.message };
      }

      // Check services
      const { data: existingServices } = await supabase.from('services').select('id').limit(1);
      if (!existingServices || existingServices.length === 0) {
        const { error } = await supabase.from('services').insert(
          defaultServices.map((s) => ({
            name: s.name,
            description: s.description,
            duration_minutes: s.duration_minutes,
            price: s.price,
            is_active: s.is_active,
          }))
        );
        if (error) return { success: false, message: error.message };
      }

      // Check business hours
      const { data: existingHours } = await supabase.from('business_hours').select('id').limit(1);
      if (!existingHours || existingHours.length === 0) {
        const { error } = await supabase.from('business_hours').insert(
          defaultBusinessHours.map((bh) => ({
            weekday: bh.weekday,
            is_open: bh.is_open,
            start_time: bh.start_time,
            end_time: bh.end_time,
          }))
        );
        if (error) return { success: false, message: error.message };
      }

      return { success: true, message: 'Database successfully seeded with default services, settings, and hours.' };
    } catch (err: unknown) {
      if (isNetworkFetchError(err)) {
        return {
          success: false,
          message: 'Unable to reach Supabase. Check your Project URL and make sure your project is active.',
        };
      }
      const msg = err instanceof Error ? err.message : String(err);
      return { success: false, message: msg };
    }
  },
};
