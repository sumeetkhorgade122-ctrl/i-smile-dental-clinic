import { createClient } from '@supabase/supabase-js';

const PLACEHOLDER_PATTERNS = [
  'your-project',
  'your-anon',
  'paste_your',
  'placeholder-project',
  'placeholder-anon-key',
  'example.com',
];

const isPlaceholderValue = (val: string): boolean => {
  const lower = val.toLowerCase();
  return PLACEHOLDER_PATTERNS.some((pattern) => lower.includes(pattern));
};

/**
 * Normalizes a Supabase URL, automatically converting Dashboard URLs
 * (e.g. https://supabase.com/dashboard/project/<ref>) into the API URL
 * (https://<ref>.supabase.co) and stripping trailing paths/slashes.
 */
export const normalizeSupabaseUrl = (raw: string): string => {
  const cleaned = raw.trim().replace(/^["']+|["']+$/g, '');
  if (!cleaned || isPlaceholderValue(cleaned)) {
    return '';
  }

  // Convert Supabase Dashboard URLs automatically if pasted by mistake
  const dashboardMatch = cleaned.match(
    /^https?:\/\/(?:app\.)?supabase\.com\/(?:dashboard\/)?project\/([a-z0-9-]+)(?:\/.*)?$/i
  );
  if (dashboardMatch && dashboardMatch[1]) {
    return `https://${dashboardMatch[1]}.supabase.co`;
  }

  try {
    const parsed = new URL(cleaned);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return '';
    }
    if (!parsed.hostname || !parsed.hostname.includes('.')) {
      return '';
    }
    // Strip accidental /rest/v1, /auth/v1, /storage/v1 or trailing slashes
    const cleanPath = parsed.pathname
      .replace(/\/(rest|auth|storage|realtime)\/v1.*$/i, '')
      .replace(/\/+$/, '');
    return `${parsed.origin}${cleanPath}`;
  } catch {
    return '';
  }
};

/**
 * Sanitizes a Supabase anon/publishable API key by stripping quotes,
 * whitespace, and control characters that would cause fetch header errors.
 */
export const sanitizeSupabaseKey = (raw: string): string => {
  const cleaned = raw
    .trim()
    .replace(/^["']+|["']+$/g, '')
    .replace(/[\r\n\t\s]+/g, '');
  if (!cleaned || isPlaceholderValue(cleaned)) {
    return '';
  }
  return cleaned;
};

const getEnvOrStorage = (
  envKey: 'VITE_SUPABASE_URL' | 'VITE_SUPABASE_ANON_KEY',
  storageKey: string,
  sanitizer: (val: string) => string
): string => {
  const envVal = import.meta.env[envKey];
  if (envVal && typeof envVal === 'string') {
    const normalizedEnv = sanitizer(envVal);
    if (normalizedEnv) {
      return normalizedEnv;
    }
  }
  if (typeof window !== 'undefined') {
    try {
      const stored = window.localStorage.getItem(storageKey);
      if (stored && typeof stored === 'string') {
        const normalizedStored = sanitizer(stored);
        if (normalizedStored) {
          return normalizedStored;
        }
      }
    } catch {
      // Ignore storage access errors in restricted iframes
    }
  }
  return '';
};

export const activeSupabaseUrl = getEnvOrStorage(
  'VITE_SUPABASE_URL',
  'custom_supabase_url',
  normalizeSupabaseUrl
);

export const activeSupabaseAnonKey = getEnvOrStorage(
  'VITE_SUPABASE_ANON_KEY',
  'custom_supabase_anon_key',
  sanitizeSupabaseKey
);

export const isSupabaseConfigured = Boolean(
  activeSupabaseUrl &&
  activeSupabaseAnonKey &&
  activeSupabaseUrl.startsWith('http')
);

/**
 * Detects network/CORS/DNS fetch failures from Supabase responses or thrown errors.
 */
export const isNetworkFetchError = (err: unknown): boolean => {
  if (!err) return false;
  const parts: string[] = [];
  if (typeof err === 'string') {
    parts.push(err);
  } else if (typeof err === 'object') {
    const record = err as Record<string, unknown>;
    if (typeof record.message === 'string') parts.push(record.message);
    if (typeof record.details === 'string') parts.push(record.details);
    if (typeof record.name === 'string') parts.push(record.name);
  }
  const combined = parts.join(' ').toLowerCase();
  return (
    combined.includes('failed to fetch') ||
    combined.includes('networkerror') ||
    combined.includes('network request failed') ||
    combined.includes('load failed') ||
    combined.includes('fetch failed') ||
    combined.includes('err_name_not_resolved') ||
    combined.includes('err_connection') ||
    combined.includes('aborterror')
  );
};

/**
 * Tests live connectivity to a Supabase REST endpoint before saving or reporting status.
 */
export const testSupabaseConnection = async (
  rawUrl: string,
  rawKey: string
): Promise<{ ok: boolean; normalizedUrl: string; error?: string }> => {
  const normalizedUrl = normalizeSupabaseUrl(rawUrl);
  const cleanKey = sanitizeSupabaseKey(rawKey);

  if (!normalizedUrl) {
    return {
      ok: false,
      normalizedUrl: '',
      error:
        'Please enter a valid Supabase Project URL (e.g. https://your-project-ref.supabase.co).',
    };
  }

  if (!cleanKey) {
    return {
      ok: false,
      normalizedUrl,
      error: 'Please enter a valid Supabase anon public API key.',
    };
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 7000);

  try {
    const response = await fetch(`${normalizedUrl}/rest/v1/`, {
      method: 'GET',
      headers: {
        apikey: cleanKey,
        Authorization: `Bearer ${cleanKey}`,
      },
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.status === 401 || response.status === 403) {
      return {
        ok: false,
        normalizedUrl,
        error:
          'Supabase rejected the API key (401/403). Please verify you copied the anon public key from Project Settings → API.',
      };
    }

    if (response.ok || response.status === 404) {
      return { ok: true, normalizedUrl };
    }

    return {
      ok: false,
      normalizedUrl,
      error: `Supabase responded with status ${response.status}. Verify your Project URL and project status.`,
    };
  } catch (err: unknown) {
    clearTimeout(timeoutId);
    const isAbort = err instanceof Error && err.name === 'AbortError';
    return {
      ok: false,
      normalizedUrl,
      error: isAbort
        ? 'Connection timed out. Check that your Supabase project is active and not paused.'
        : 'Unable to reach this Supabase Project URL. Verify the URL is https://<project-ref>.supabase.co and that your Supabase project is active (not paused).',
    };
  }
};

// Client instance: initialized with active or placeholder credentials
export const supabase = createClient(
  isSupabaseConfigured ? activeSupabaseUrl : 'https://placeholder-project.supabase.co',
  isSupabaseConfigured ? activeSupabaseAnonKey : 'placeholder-anon-key'
);

export const setCustomSupabaseCredentials = (url: string, anonKey: string) => {
  if (typeof window !== 'undefined') {
    const normalizedUrl = normalizeSupabaseUrl(url) || url.trim();
    const cleanKey = sanitizeSupabaseKey(anonKey) || anonKey.trim();
    window.localStorage.setItem('custom_supabase_url', normalizedUrl);
    window.localStorage.setItem('custom_supabase_anon_key', cleanKey);
    window.location.reload();
  }
};

export const clearCustomSupabaseCredentials = () => {
  if (typeof window !== 'undefined') {
    window.localStorage.removeItem('custom_supabase_url');
    window.localStorage.removeItem('custom_supabase_anon_key');
    window.location.reload();
  }
};
