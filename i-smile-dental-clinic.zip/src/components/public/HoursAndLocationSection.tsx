import React from 'react';
import { Clock, MapPin, Phone, Mail, Navigation, CheckCircle2, XCircle } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { weekdayNames } from '../../data/defaultData';
import { formatTimeRangeForDisplay } from '../../utils/dateTime';

export const HoursAndLocationSection: React.FC = () => {
  const { settings, businessHours } = useClinic();

  // Sort business hours by weekday starting Monday (1) through Sunday (0)
  const sortedHours = [...businessHours].sort((a, b) => {
    const orderA = a.weekday === 0 ? 7 : a.weekday;
    const orderB = b.weekday === 0 ? 7 : b.weekday;
    return orderA - orderB;
  });

  const todayWeekday = new Date().getDay();

  return (
    <section className="py-20 bg-white border-t border-slate-100" id="hours">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-widest text-teal-700 block mb-2">
            Visit Our Clinic
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Hours &amp; Location
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-2">
            Conveniently located with dedicated patient parking and wheelchair-accessible treatment suites.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Clinic Contact & Map info */}
          <div className="lg:col-span-6 bg-slate-50 rounded-2xl p-8 border border-slate-200/80 flex flex-col justify-between space-y-6">
            <div>
              <h3 className="text-xl font-bold text-slate-900 mb-6">Contact &amp; Directions</h3>

              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white text-teal-700 border border-slate-200 shadow-xs flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Clinic Address</h4>
                    <p className="text-xs sm:text-sm text-slate-600 mt-0.5">{settings.clinic_address}</p>
                    <span className="text-[11px] text-teal-700 font-medium inline-block mt-1">
                      Validated GPS Navigation Available
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white text-teal-700 border border-slate-200 shadow-xs flex items-center justify-center flex-shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Direct Telephone</h4>
                    <a
                      href={`tel:${settings.clinic_phone}`}
                      className="text-xs sm:text-sm text-slate-600 hover:text-teal-700 font-medium mt-0.5 block"
                    >
                      {settings.clinic_phone}
                    </a>
                    <p className="text-[11px] text-slate-400 mt-0.5">Assistance available during business hours</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white text-teal-700 border border-slate-200 shadow-xs flex items-center justify-center flex-shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Email Inquiries</h4>
                    <a
                      href={`mailto:${settings.clinic_email}`}
                      className="text-xs sm:text-sm text-slate-600 hover:text-teal-700 font-medium mt-0.5 block"
                    >
                      {settings.clinic_email}
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Simulated Map Visual Card */}
            <div className="rounded-xl overflow-hidden border border-slate-200 bg-white p-4">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-800 mb-2">
                <span className="flex items-center gap-1.5">
                  <Navigation className="w-3.5 h-3.5 text-teal-600" />
                  Clinic Facility Parking
                </span>
                <span className="text-[11px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  Complimentary Valet &amp; Parking
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Ground-floor entrance accessible from the medical plaza courtyard. Transit station is within a 3-minute walking distance.
              </p>
            </div>
          </div>

          {/* Business Hours Table */}
          <div className="lg:col-span-6 bg-white rounded-2xl p-8 border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Operating Schedule</h3>
                    <p className="text-xs text-slate-500">Live updated clinic hours</p>
                  </div>
                </div>
              </div>

              <div className="divide-y divide-slate-100">
                {sortedHours.map((bh) => {
                  const isToday = bh.weekday === todayWeekday;
                  const name = weekdayNames[bh.weekday];

                  return (
                    <div
                      key={bh.id || bh.weekday}
                      className={`py-3 flex items-center justify-between text-xs sm:text-sm ${
                        isToday ? 'bg-teal-50/80 px-3 rounded-lg font-bold text-teal-950' : 'text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span>{name}</span>
                        {isToday && (
                          <span className="text-[10px] bg-teal-700 text-white px-2 py-0.5 rounded-full font-bold uppercase">
                            Today
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {bh.is_open ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="font-mono text-xs">
                              {formatTimeRangeForDisplay(bh.start_time, bh.end_time)}
                            </span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-3.5 h-3.5 text-slate-400" />
                            <span className="text-slate-400 italic">Closed</span>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-6 p-4 rounded-xl bg-slate-50 border border-slate-200/70 text-xs text-slate-600">
              <span className="font-semibold text-slate-900 block mb-0.5">
                Notice Period: {settings.booking_notice_hours} hours advance notice required for online booking.
              </span>
              Need emergency treatment sooner? Call our urgent care line at {settings.clinic_phone}.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
