import React from 'react';
import { Shield, Sparkles, CheckCircle2, Heart, Award, Users } from 'lucide-react';
import { clinicImages } from '../../data/clinicImages';
import { ImageWithFallback } from '../common/ImageWithFallback';
import { useClinic } from '../../context/ClinicContext';

export const AboutSection: React.FC = () => {
  const { settings } = useClinic();

  const values = [
    {
      title: 'Comfort-Centered Environment',
      desc: 'Ergonomic treatment suites designed with acoustic dampening and gentle touch protocols.',
    },
    {
      title: 'Preventive-First Philosophy',
      desc: 'We focus on preserving natural tooth structure through early detection and minimally invasive care.',
    },
    {
      title: 'Advanced Clinical Technology',
      desc: 'High-definition intraoral 3D scanning, ultrasonic calculus removal, and digital treatment previews.',
    },
    {
      title: 'Transparent Patient Care',
      desc: 'Every procedure is discussed with clear visual aids, honest recommendations, and zero guesswork.',
    },
  ];

  return (
    <section className="py-20 bg-white overflow-hidden" id="about">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Asymmetrical Double Image Composition */}
          <div className="lg:col-span-6 relative">
            <div className="relative">
              {/* Primary large image */}
              <div className="rounded-3xl overflow-hidden shadow-2xl border-4 border-white aspect-[4/3] bg-slate-100 relative z-10">
                <ImageWithFallback
                  src={clinicImages.about.url}
                  alt={clinicImages.about.alt}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Secondary overlapping image */}
              <div className="hidden sm:block absolute -bottom-8 -right-6 w-3/5 rounded-2xl overflow-hidden shadow-2xl border-4 border-white aspect-[4/3] bg-slate-100 z-20">
                <ImageWithFallback
                  src={clinicImages.dentistInAction.url}
                  alt={clinicImages.dentistInAction.alt}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Floating Stat Card */}
              <div className="absolute -top-6 -left-4 bg-slate-900 text-white rounded-2xl p-4 shadow-xl z-30 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-base font-extrabold">12+ Years</p>
                  <p className="text-[11px] text-slate-400">Clinical Smile Excellence</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Narrative & Values */}
          <div className="lg:col-span-6 space-y-6">
            <span className="text-xs font-bold uppercase tracking-widest text-teal-700 block">
              About {settings.clinic_name}
            </span>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
              A Modern Dental Practice Where Calm Meets Clinical Precision
            </h2>

            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              At {settings.clinic_name}, we have re-engineered the dental visit from the ground up.
              We recognize that many patients feel uneasy about dental visits. That is why our clinic
              was designed to evoke warmth, tranquility, and genuine human connection.
            </p>

            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              Our multidisciplinary team specializes in preventive dental wellness, gentle restorative
              dentistry, and cosmetic smile designs. We leverage the latest in dental advancements—ensuring treatments are faster, gentler, and longer-lasting.
            </p>

            {/* Value checklist grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {values.map((v, i) => (
                <div key={i} className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                  <div className="flex items-center gap-2 text-teal-800 font-bold text-xs">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 flex-shrink-0" />
                    <span>{v.title}</span>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed pl-6">{v.desc}</p>
                </div>
              ))}
            </div>

            {/* Doctor quote snippet */}
            <div className="p-4 rounded-xl bg-teal-50/60 border border-teal-100 flex items-start gap-3 mt-4">
              <Sparkles className="w-5 h-5 text-teal-700 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-teal-900 italic leading-relaxed">
                &ldquo;Our promise is simple: we will never rush your treatment, we will always listen to your comfort level, and we will protect your oral health with the most advanced, compassionate care available.&rdquo;
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
