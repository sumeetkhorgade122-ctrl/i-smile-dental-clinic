import React from 'react';
import { Calendar, ArrowRight, ShieldCheck, Sparkles, Star, Clock, CheckCircle2 } from 'lucide-react';
import { clinicImages } from '../../data/clinicImages';
import { ImageWithFallback } from '../common/ImageWithFallback';
import { useClinic } from '../../context/ClinicContext';

interface HeroSectionProps {
  onBookClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onBookClick }) => {
  const { settings, activeServices } = useClinic();

  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:py-24 bg-gradient-to-b from-white via-slate-50/50 to-slate-100/30" id="hero-section">
      {/* Subtle background ambient lighting */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-teal-200/30 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-cyan-100/40 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Copy & CTAs */}
          <div className="lg:col-span-7 space-y-6 lg:pr-6">
            {/* Trust Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-50 border border-teal-200/70 text-teal-800 text-xs font-semibold shadow-xs">
              <span className="flex h-2 w-2 rounded-full bg-teal-600 animate-pulse" />
              <span>Welcoming New Patients &amp; Families</span>
              <span className="text-teal-400">•</span>
              <span className="flex items-center gap-1 text-teal-900">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                4.9 Patient Trust
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.12]">
              Gentle Care, Radiant Smiles.{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-700 via-teal-600 to-cyan-600">
                Modern Dentistry
              </span>{' '}
              Built Around Your Comfort.
            </h1>

            {/* Supporting Copy */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl font-normal">
              Step into a warm, calming dental studio designed to alleviate anxiety. We combine
              advanced low-radiation diagnostics, painless ultrasonic hygiene, and personalized care plans to keep your teeth healthy for a lifetime.
            </p>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5">
              <button
                id="hero-primary-book-btn"
                onClick={onBookClick}
                className="inline-flex items-center justify-center gap-2.5 bg-gradient-to-r from-teal-700 to-teal-600 hover:from-teal-800 hover:to-teal-700 text-white font-semibold text-base px-7 py-3.5 rounded-xl shadow-lg shadow-teal-700/25 hover:shadow-xl hover:shadow-teal-700/35 transition-all duration-200 active:scale-95 cursor-pointer"
              >
                <Calendar className="w-5 h-5" />
                <span>Schedule Your Visit</span>
                <ArrowRight className="w-4 h-4 ml-0.5" />
              </button>

              <a
                href="#services"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl text-slate-700 hover:text-teal-800 font-semibold text-base bg-white hover:bg-slate-50 border border-slate-200 transition-colors shadow-xs"
                id="hero-secondary-services-btn"
              >
                <span>View Treatments &amp; Fees</span>
              </a>
            </div>

            {/* Micro Highlights */}
            <div className="pt-6 grid grid-cols-3 gap-4 border-t border-slate-200/80 max-w-xl">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-teal-700 font-bold text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Real-Time</span>
                </div>
                <p className="text-xs text-slate-500">Live booking slots calculated directly from clinic schedule</p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-teal-700 font-bold text-sm">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Zero Anxiety</span>
                </div>
                <p className="text-xs text-slate-500">Gentle touch techniques &amp; calming clinical rooms</p>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-teal-700 font-bold text-sm">
                  <Clock className="w-4 h-4" />
                  <span>No Waiting</span>
                </div>
                <p className="text-xs text-slate-500">Respect for your time with guaranteed on-time appointments</p>
              </div>
            </div>
          </div>

          {/* Right Column: Imagery with Layered Depth */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Outer decorative glow frame */}
              <div className="absolute -inset-2 rounded-3xl bg-gradient-to-tr from-teal-500/20 via-cyan-400/20 to-teal-300/10 blur-xl -z-10" />

              {/* Main Image Card */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/80 bg-white aspect-[4/3] sm:aspect-[5/4] lg:aspect-[4/3]">
                <ImageWithFallback
                  src={clinicImages.hero.url}
                  alt={clinicImages.hero.alt}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-transparent to-transparent pointer-events-none" />
                <div className="absolute bottom-4 left-4 right-4 text-white text-xs font-medium flex items-center justify-between pointer-events-none">
                  <span className="bg-slate-900/70 backdrop-blur-md px-3 py-1 rounded-full border border-white/20">
                    Modern Treatment Suite 01
                  </span>
                  <span className="bg-teal-700/80 backdrop-blur-md px-3 py-1 rounded-full">
                    Low-Radiation Digital Suite
                  </span>
                </div>
              </div>

              {/* Floating Quick Booking Pill */}
              <div
                onClick={onBookClick}
                className="absolute -bottom-6 -left-4 sm:-left-6 bg-white rounded-2xl p-4 shadow-xl border border-slate-100 flex items-center gap-3.5 max-w-xs cursor-pointer hover:scale-102 transition-transform duration-200"
              >
                <div className="w-11 h-11 rounded-xl bg-teal-100/90 text-teal-700 flex items-center justify-center flex-shrink-0">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                    <span>Booking Open Today</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {activeServices.length} Dental Services available online
                  </p>
                </div>
              </div>

              {/* Floating Doctor Badge */}
              <div className="hidden sm:flex absolute -top-5 -right-4 bg-white/95 backdrop-blur-md rounded-2xl p-3.5 shadow-lg border border-slate-100 items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-cyan-100 text-cyan-800 flex items-center justify-center font-bold text-xs">
                  DR
                </div>
                <div className="text-left">
                  <p className="text-xs font-bold text-slate-900">Expert Dental Team</p>
                  <p className="text-[11px] text-teal-700 font-medium">Preventive &amp; Cosmetic</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
