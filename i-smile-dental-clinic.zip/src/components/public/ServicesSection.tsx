import React from 'react';
import { Clock, Tag, Calendar, ArrowRight, Sparkles } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { getServiceImage } from '../../data/clinicImages';
import { ImageWithFallback } from '../common/ImageWithFallback';
import { Service } from '../../types/database';

interface ServicesSectionProps {
  onSelectService: (service: Service) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  const { activeServices, loading, error } = useClinic();

  return (
    <section className="py-20 bg-slate-50/50" id="services">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div className="max-w-2xl">
            <span className="text-xs font-bold uppercase tracking-widest text-teal-700 block mb-2">
              Comprehensive Oral Care
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Modern Dental Services &amp; Transparent Pricing
            </h2>
            <p className="text-slate-600 text-sm sm:text-base mt-2">
              Every smile is unique. Select a specialized dental treatment below to review duration, fees, and real-time appointment availability.
            </p>
          </div>

          <div className="hidden sm:flex items-center gap-2 bg-white px-4 py-2 rounded-xl border border-slate-200 shadow-xs text-xs text-slate-600">
            <Sparkles className="w-4 h-4 text-teal-600" />
            <span>{activeServices.length} Active Services Available for Online Booking</span>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div
                key={n}
                className="bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm animate-pulse"
              >
                <div className="h-52 bg-slate-200" />
                <div className="p-6 space-y-3">
                  <div className="h-5 bg-slate-200 rounded w-3/4" />
                  <div className="h-4 bg-slate-200 rounded w-full" />
                  <div className="h-4 bg-slate-200 rounded w-2/3" />
                  <div className="pt-4 flex justify-between">
                    <div className="h-6 bg-slate-200 rounded w-1/3" />
                    <div className="h-8 bg-slate-200 rounded w-1/3" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Error State */}
        {!loading && error && (
          <div className="p-8 text-center bg-amber-50 rounded-2xl border border-amber-200 max-w-xl mx-auto">
            <p className="text-amber-800 text-sm font-semibold">{error}</p>
            <p className="text-xs text-amber-700 mt-1">
              Please check your Supabase configuration or network connection.
            </p>
          </div>
        )}

        {/* Services Cards Grid */}
        {!loading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {activeServices.map((service) => {
              const imageConfig = getServiceImage(service.name);

              return (
                <div
                  key={service.id}
                  className="bg-white rounded-2xl overflow-hidden border border-slate-200/80 shadow-sm hover:shadow-xl hover:border-teal-300 transition-all duration-300 flex flex-col group"
                  id={`service-card-${service.id}`}
                >
                  {/* Service Image Container */}
                  <div className="relative h-52 overflow-hidden bg-slate-100">
                    <ImageWithFallback
                      src={imageConfig.url}
                      alt={imageConfig.alt}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />

                    {/* Duration Badge */}
                    <div className="absolute top-3.5 left-3.5 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold text-slate-800 flex items-center gap-1.5 shadow-sm">
                      <Clock className="w-3.5 h-3.5 text-teal-600" />
                      <span>{service.duration_minutes} mins</span>
                    </div>

                    {/* Price Pill */}
                    <div className="absolute bottom-3.5 right-3.5 bg-teal-700 text-white px-3.5 py-1 rounded-full text-sm font-bold shadow-md">
                      ${Number(service.price).toFixed(2)}
                    </div>
                  </div>

                  {/* Service Details */}
                  <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 group-hover:text-teal-700 transition-colors line-clamp-1">
                        {service.name}
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed line-clamp-3">
                        {service.description}
                      </p>
                    </div>

                    {/* Action CTA */}
                    <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                        <Tag className="w-3.5 h-3.5 text-teal-600" />
                        <span>Fixed Clinic Fee</span>
                      </div>

                      <button
                        id={`btn-book-service-${service.id}`}
                        onClick={() => onSelectService(service)}
                        className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl transition-all duration-200 group-hover:bg-teal-700 shadow-sm cursor-pointer active:scale-95"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>Book Appointment</span>
                        <ArrowRight className="w-3.5 h-3.5 ml-0.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
