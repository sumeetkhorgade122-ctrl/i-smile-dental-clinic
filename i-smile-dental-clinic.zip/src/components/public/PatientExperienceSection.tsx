import React from 'react';
import { CalendarCheck, UserCheck, Stethoscope, HeartPulse } from 'lucide-react';

export const PatientExperienceSection: React.FC = () => {
  const steps = [
    {
      number: '01',
      icon: CalendarCheck,
      title: 'Seamless Online Booking',
      desc: 'Select your treatment, pick a live verified time slot, and reserve your visit instantly without phone tag.',
    },
    {
      number: '02',
      icon: UserCheck,
      title: 'Warm Welcome & Zero Wait',
      desc: 'Arrive at our calm lounge. Digital check-in ensures your treatment suite is prepared the moment you step in.',
    },
    {
      number: '03',
      icon: Stethoscope,
      title: 'Gentle, Explain-As-We-Go Care',
      desc: 'Our dentists take time to listen, explain findings on high-def screens, and proceed at your comfort level.',
    },
    {
      number: '04',
      icon: HeartPulse,
      title: 'Long-Term Smile Health',
      desc: 'Receive clear post-visit guidance, upfront breakdown of any future options, and proactive preventive support.',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-white to-slate-50 border-t border-slate-100" id="experience">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-widest text-teal-700 block mb-2">
            The Patient Journey
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Designed to Make Dentistry Relaxing &amp; Stress-Free
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-2">
            From the moment you reserve your appointment online to your finished treatment, every detail is engineered for your peace of mind.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow relative flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-extrabold text-slate-200 font-mono">
                      {step.number}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2">{step.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{step.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
