import React from 'react';
import { ClinicSettings, Service, TimeSlot } from '../../../types/database';
import { PatientFormData } from './Step4PatientDetails';
import { formatDateForDisplay, formatTimeRangeForDisplay } from '../../../utils/dateTime';
import { ArrowLeft, CheckCircle, ShieldCheck, Sparkles, AlertCircle, Loader2 } from 'lucide-react';

interface Step5SummaryProps {
  clinicSettings: ClinicSettings;
  service: Service;
  selectedDate: string;
  selectedSlot: TimeSlot;
  patientData: PatientFormData;
  onBack: () => void;
  onSubmit: () => void;
  submitting: boolean;
  submitError: string | null;
}

export const Step5Summary: React.FC<Step5SummaryProps> = ({
  clinicSettings,
  service,
  selectedDate,
  selectedSlot,
  patientData,
  onBack,
  onSubmit,
  submitting,
  submitError,
}) => {
  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="text-center max-w-xl mx-auto">
        <h3 className="text-xl font-bold text-slate-900">Step 5: Review Appointment Summary</h3>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Please confirm your dental appointment details before submitting your reservation request.
        </p>
      </div>

      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/80 shadow-xs max-w-2xl mx-auto space-y-6">
        {submitError && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-rose-800 text-xs">
            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Submission Failed</p>
              <p className="mt-0.5">{submitError}</p>
            </div>
          </div>
        )}

        {/* Clinic & Service Summary */}
        <div className="bg-gradient-to-br from-teal-50/70 to-slate-50 p-5 rounded-xl border border-teal-100/80 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] uppercase font-bold tracking-wider text-teal-800">
              {clinicSettings.clinic_name}
            </span>
            <span className="text-xs bg-teal-700 text-white font-bold px-2.5 py-0.5 rounded-full">
              ${Number(service.price).toFixed(2)}
            </span>
          </div>

          <div>
            <h4 className="text-lg font-extrabold text-slate-900">{service.name}</h4>
            <p className="text-xs text-slate-600 mt-1">{service.description}</p>
          </div>

          <div className="pt-2 border-t border-teal-100 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-2">
            <span>Duration: <strong className="text-slate-900">{service.duration_minutes} minutes</strong></span>
            <span>Clinic: <strong className="text-slate-900">{clinicSettings.clinic_phone}</strong></span>
          </div>
        </div>

        {/* Date & Time Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/70">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Appointment Date
            </span>
            <p className="text-sm font-bold text-slate-900">
              {formatDateForDisplay(selectedDate)}
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/70">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Appointment Time
            </span>
            <p className="text-sm font-bold text-slate-900 font-mono">
              {formatTimeRangeForDisplay(selectedSlot.formattedStartTime, selectedSlot.formattedEndTime)}
            </p>
          </div>
        </div>

        {/* Patient Details Summary */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/70 space-y-2 text-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
            Patient Contact Details
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-700">
            <div>
              <span className="text-slate-400 block text-[11px]">Patient Name:</span>
              <span className="font-semibold text-slate-900">{patientData.full_name}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Contact Telephone:</span>
              <span className="font-semibold text-slate-900">{patientData.phone}</span>
            </div>
            <div className="sm:col-span-2">
              <span className="text-slate-400 block text-[11px]">Email Address:</span>
              <span className="font-semibold text-slate-900">{patientData.email}</span>
            </div>
            {patientData.notes && (
              <div className="sm:col-span-2 pt-1 border-t border-slate-200/50">
                <span className="text-slate-400 block text-[11px]">Notes &amp; Concerns:</span>
                <span className="text-slate-600 italic">{patientData.notes}</span>
              </div>
            )}
          </div>
        </div>

        {/* Clinic Commitment */}
        <div className="flex items-center gap-2 text-xs text-slate-500 pt-1">
          <ShieldCheck className="w-4 h-4 text-teal-600 flex-shrink-0" />
          <span>Strict patient privacy. Your health data and contact info are safeguarded.</span>
        </div>
      </div>

      <div className="flex justify-between pt-4 border-t border-slate-100">
        <button
          type="button"
          disabled={submitting}
          onClick={onBack}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-slate-700 hover:bg-slate-100 rounded-xl text-sm font-semibold transition-colors cursor-pointer disabled:opacity-50"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Edit Info</span>
        </button>

        <button
          id="step5-submit-btn"
          type="button"
          disabled={submitting}
          onClick={onSubmit}
          className="inline-flex items-center gap-2 px-8 py-3.5 bg-gradient-to-r from-teal-700 to-teal-600 hover:from-teal-800 hover:to-teal-700 text-white text-sm font-bold rounded-xl shadow-lg shadow-teal-700/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer active:scale-95"
        >
          {submitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Submitting Appointment...</span>
            </>
          ) : (
            <>
              <CheckCircle className="w-4 h-4" />
              <span>Confirm &amp; Book Appointment</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
