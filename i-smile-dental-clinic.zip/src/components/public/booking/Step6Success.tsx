import React from 'react';
import { Appointment, ClinicSettings, Service, TimeSlot } from '../../../types/database';
import { formatDateForDisplay, formatTimeRangeForDisplay } from '../../../utils/dateTime';
import { CheckCircle2, Calendar, MapPin, Phone, Mail, ArrowRight, Printer, Sparkles } from 'lucide-react';

interface Step6SuccessProps {
  appointment: Appointment;
  service: Service;
  selectedDate: string;
  selectedSlot: TimeSlot;
  clinicSettings: ClinicSettings;
  onReset: () => void;
}

export const Step6Success: React.FC<Step6SuccessProps> = ({
  appointment,
  service,
  selectedDate,
  selectedSlot,
  clinicSettings,
  onReset,
}) => {
  return (
    <div className="space-y-6 animate-in zoom-in-95 duration-400 max-w-2xl mx-auto" id="booking-success-view">
      {/* Success Badge & Header */}
      <div className="text-center space-y-3">
        <div className="w-16 h-16 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center mx-auto shadow-sm ring-8 ring-teal-50">
          <CheckCircle2 className="w-9 h-9 text-teal-600" />
        </div>

        <span className="text-[11px] font-bold uppercase tracking-widest text-teal-700 block">
          Appointment Request Received
        </span>

        <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Thank You, {appointment.full_name.split(' ')[0]}!
        </h3>

        <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
          Your dental appointment request has been successfully recorded in our system.
          Our clinical coordinator will review your reservation and reach out if any preparation is needed.
        </p>
      </div>

      {/* Structured Appointment Confirmation Card */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/80 shadow-md space-y-6">
        {/* Status Pill */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500">Booking Reference:</span>
            <span className="text-xs font-mono font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
              {appointment.id.substring(0, 8).toUpperCase()}
            </span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            <span className="capitalize">Status: {appointment.status}</span>
          </div>
        </div>

        {/* Selected Service Detail */}
        <div className="flex items-start justify-between bg-slate-50 p-4 rounded-xl border border-slate-200/70">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
              Selected Dental Treatment
            </span>
            <h4 className="text-base font-bold text-slate-900 mt-0.5">{service.name}</h4>
            <p className="text-xs text-slate-500 mt-0.5">
              Duration: {service.duration_minutes} minutes • Standard fee: ${Number(service.price).toFixed(2)}
            </p>
          </div>
        </div>

        {/* Date & Time Highlight */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 bg-teal-50/50 rounded-xl border border-teal-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-teal-800 block mb-1">
              Confirmed Date
            </span>
            <p className="text-sm font-bold text-slate-900">
              {formatDateForDisplay(selectedDate)}
            </p>
          </div>

          <div className="p-4 bg-teal-50/50 rounded-xl border border-teal-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-teal-800 block mb-1">
              Reserved Time Window
            </span>
            <p className="text-sm font-bold text-slate-900 font-mono">
              {formatTimeRangeForDisplay(selectedSlot.formattedStartTime, selectedSlot.formattedEndTime)}
            </p>
          </div>
        </div>

        {/* Clinic Location & Instructions */}
        <div className="pt-2 border-t border-slate-100 space-y-2 text-xs text-slate-600">
          <h5 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
            Clinic Visit Information
          </h5>
          <div className="flex items-start gap-2">
            <MapPin className="w-4 h-4 text-teal-600 flex-shrink-0 mt-0.5" />
            <span>{clinicSettings.clinic_address}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4 text-teal-600 flex-shrink-0" />
            <span>Questions or reschedule: {clinicSettings.clinic_phone}</span>
          </div>
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-teal-600 flex-shrink-0" />
            <span>Confirmation sent to: {appointment.email}</span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
        <button
          type="button"
          onClick={() => window.print()}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer shadow-xs"
        >
          <Printer className="w-4 h-4" />
          <span>Print Summary</span>
        </button>

        <button
          id="btn-return-home-after-booking"
          type="button"
          onClick={onReset}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer active:scale-95"
        >
          <span>Return to Clinic Website</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
