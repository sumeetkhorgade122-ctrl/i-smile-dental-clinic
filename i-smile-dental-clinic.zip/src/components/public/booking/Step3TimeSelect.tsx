import React, { useEffect, useState } from 'react';
import { Appointment, BlockedDate, BusinessHour, ClinicSettings, Service, TimeSlot } from '../../../types/database';
import { generateAvailableSlots } from '../../../utils/availability';
import { appointmentService } from '../../../services/appointmentService';
import { formatDateForDisplay } from '../../../utils/dateTime';
import { ArrowLeft, ArrowRight, Clock, Check, AlertCircle, Loader2 } from 'lucide-react';

interface Step3TimeSelectProps {
  service: Service;
  selectedDate: string; // YYYY-MM-DD
  selectedSlot: TimeSlot | null;
  onSelectSlot: (slot: TimeSlot) => void;
  onNext: () => void;
  onBack: () => void;
  businessHours: BusinessHour[];
  blockedDates: BlockedDate[];
  clinicSettings: ClinicSettings;
}

export const Step3TimeSelect: React.FC<Step3TimeSelectProps> = ({
  service,
  selectedDate,
  selectedSlot,
  onSelectSlot,
  onNext,
  onBack,
  businessHours,
  blockedDates,
  clinicSettings,
}) => {
  const [loading, setLoading] = useState(true);
  const [availableSlots, setAvailableSlots] = useState<TimeSlot[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    async function loadSlots() {
      try {
        setLoading(true);
        setError(null);
        // 1. Fetch live appointments for the chosen date from Supabase
        const existingAppointments = await appointmentService.getAppointmentsForDate(selectedDate);

        if (!isMounted) return;

        // 2. Generate available slots via strict availability engine
        const slots = generateAvailableSlots({
          selectedDate,
          service,
          clinicSettings,
          businessHours,
          blockedDates,
          existingAppointments,
        });

        setAvailableSlots(slots);
      } catch (err: unknown) {
        console.error('Error generating slots:', err);
        if (isMounted) {
          setError('Unable to load available times. Please try again or select another date.');
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadSlots();

    return () => {
      isMounted = false;
    };
  }, [selectedDate, service, clinicSettings, businessHours, blockedDates]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="text-center max-w-xl mx-auto">
        <h3 className="text-xl font-bold text-slate-900">Step 3: Select an Available Time</h3>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Showing real-time openings for <span className="font-semibold text-slate-800">{formatDateForDisplay(selectedDate)}</span>{' '}
          based on your {service.duration_minutes}-minute treatment.
        </p>
      </div>

      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        {loading && (
          <div className="py-16 flex flex-col items-center justify-center text-slate-400 gap-3">
            <Loader2 className="w-8 h-8 text-teal-600 animate-spin" />
            <p className="text-xs font-medium text-slate-500">Checking clinic chair availability...</p>
          </div>
        )}

        {!loading && error && (
          <div className="p-6 text-center bg-amber-50 rounded-xl border border-amber-200 text-amber-800 text-xs">
            <AlertCircle className="w-5 h-5 mx-auto mb-2 text-amber-600" />
            <p className="font-semibold">{error}</p>
          </div>
        )}

        {!loading && !error && availableSlots.length === 0 && (
          <div className="py-12 text-center text-slate-500 space-y-3">
            <Clock className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="text-sm font-semibold text-slate-800">No time slots remaining for this date</p>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              All treatment chairs are reserved or the minimum advance notice period has passed. Please choose an alternate date.
            </p>
            <button
              type="button"
              onClick={onBack}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
            >
              Choose Different Date
            </button>
          </div>
        )}

        {!loading && !error && availableSlots.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-slate-600">
                {availableSlots.length} Slots Available on this day:
              </span>
              <span className="text-xs text-teal-700 font-medium">
                {service.duration_minutes} min appointment duration
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {availableSlots.map((slot, index) => {
                const isSelected = selectedSlot?.formattedStartTime === slot.formattedStartTime;

                return (
                  <button
                    key={index}
                    type="button"
                    onClick={() => onSelectSlot(slot)}
                    id={`time-slot-${slot.formattedStartTime.replace(/:/g, '-')}`}
                    className={`py-3 px-3 rounded-xl flex items-center justify-center gap-1.5 font-mono text-xs font-bold transition-all duration-200 border ${
                      isSelected
                        ? 'bg-teal-700 text-white border-teal-700 shadow-md ring-2 ring-teal-500/40 scale-105'
                        : 'bg-slate-50 hover:bg-teal-50 hover:border-teal-300 text-slate-800 border-slate-200/80 cursor-pointer'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                    <span>{slot.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-between pt-4 border-t border-slate-100">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-slate-700 hover:bg-slate-100 rounded-xl text-sm font-semibold transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Calendar</span>
        </button>

        <button
          id="step3-next-btn"
          type="button"
          disabled={!selectedSlot}
          onClick={onNext}
          className="inline-flex items-center gap-2 px-6 py-3 bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold rounded-xl shadow-md transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer active:scale-95"
        >
          <span>Continue to Patient Details</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
