import React, { useState } from 'react';
import { User, Mail, Phone, FileText, ArrowLeft, ArrowRight, AlertCircle } from 'lucide-react';

export interface PatientFormData {
  full_name: string;
  email: string;
  phone: string;
  notes: string;
}

interface Step4PatientDetailsProps {
  formData: PatientFormData;
  onChange: (data: PatientFormData) => void;
  onNext: () => void;
  onBack: () => void;
}

export const Step4PatientDetails: React.FC<Step4PatientDetailsProps> = ({
  formData,
  onChange,
  onNext,
  onBack,
}) => {
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validate = (): boolean => {
    const newErrors: { [key: string]: string } = {};

    if (!formData.full_name.trim()) {
      newErrors.full_name = 'Full name is required';
    } else if (formData.full_name.trim().length < 2) {
      newErrors.full_name = 'Please enter your full name';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (formData.phone.replace(/[^0-9]/g, '').length < 7) {
      newErrors.phone = 'Please enter a valid phone number (minimum 7 digits)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onNext();
    }
  };

  const handleChange = (field: keyof PatientFormData, value: string) => {
    onChange({ ...formData, [field]: value });
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 animate-in fade-in duration-300" noValidate>
      <div className="text-center max-w-xl mx-auto">
        <h3 className="text-xl font-bold text-slate-900">Step 4: Patient Contact Information</h3>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Please provide your contact details so our clinic reception can reach you with your appointment confirmation and clinical updates.
        </p>
      </div>

      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/80 shadow-xs max-w-2xl mx-auto space-y-5">
        {/* Full Name */}
        <div>
          <label htmlFor="patient-full-name" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Full Name <span className="text-rose-500">*</span>
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <User className="w-4 h-4" />
            </div>
            <input
              type="text"
              id="patient-full-name"
              value={formData.full_name}
              onChange={(e) => handleChange('full_name', e.target.value)}
              placeholder="e.g. Sarah Jenkins"
              className={`w-full pl-10 pr-4 py-2.5 bg-slate-50 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 transition-all ${
                errors.full_name
                  ? 'border-rose-400 focus:ring-rose-200'
                  : 'border-slate-200 focus:ring-teal-500/20 focus:border-teal-600'
              }`}
            />
          </div>
          {errors.full_name && (
            <p className="text-xs text-rose-500 mt-1.5 flex items-center gap-1 font-medium">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{errors.full_name}</span>
            </p>
          )}
        </div>

        {/* Email */}
        <div>
          <label htmlFor="patient-email" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Email Address <span className="text-rose-500">*</span>
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <Mail className="w-4 h-4" />
            </div>
            <input
              type="email"
              id="patient-email"
              value={formData.email}
              onChange={(e) => handleChange('email', e.target.value)}
              placeholder="e.g. sarah.jenkins@example.com"
              className={`w-full pl-10 pr-4 py-2.5 bg-slate-50 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 transition-all ${
                errors.email
                  ? 'border-rose-400 focus:ring-rose-200'
                  : 'border-slate-200 focus:ring-teal-500/20 focus:border-teal-600'
              }`}
            />
          </div>
          {errors.email && (
            <p className="text-xs text-rose-500 mt-1.5 flex items-center gap-1 font-medium">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{errors.email}</span>
            </p>
          )}
        </div>

        {/* Phone */}
        <div>
          <label htmlFor="patient-phone" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Mobile Telephone <span className="text-rose-500">*</span>
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <Phone className="w-4 h-4" />
            </div>
            <input
              type="tel"
              id="patient-phone"
              value={formData.phone}
              onChange={(e) => handleChange('phone', e.target.value)}
              placeholder="e.g. +1 (555) 019-2834"
              className={`w-full pl-10 pr-4 py-2.5 bg-slate-50 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 transition-all ${
                errors.phone
                  ? 'border-rose-400 focus:ring-rose-200'
                  : 'border-slate-200 focus:ring-teal-500/20 focus:border-teal-600'
              }`}
            />
          </div>
          {errors.phone && (
            <p className="text-xs text-rose-500 mt-1.5 flex items-center gap-1 font-medium">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{errors.phone}</span>
            </p>
          )}
        </div>

        {/* Notes (Optional) */}
        <div>
          <label htmlFor="patient-notes" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Clinical Notes or Concerns <span className="text-slate-400 font-normal">(Optional)</span>
          </label>
          <div className="relative">
            <textarea
              id="patient-notes"
              rows={3}
              value={formData.notes}
              onChange={(e) => handleChange('notes', e.target.value)}
              placeholder="Any current symptoms, dental anxiety, medical allergies, or specific questions..."
              className="w-full p-3 bg-slate-50 rounded-xl border border-slate-200 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 transition-all resize-none"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-between pt-4 border-t border-slate-100">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-slate-700 hover:bg-slate-100 rounded-xl text-sm font-semibold transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Time</span>
        </button>

        <button
          id="step4-next-btn"
          type="submit"
          className="inline-flex items-center gap-2 px-6 py-3 bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold rounded-xl shadow-md transition-all cursor-pointer active:scale-95"
        >
          <span>Review Summary</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </form>
  );
};
