import React from 'react';
import { Service } from '../../../types/database';
import { Clock, Check, ArrowRight } from 'lucide-react';
import { getServiceImage } from '../../../data/clinicImages';
import { ImageWithFallback } from '../../common/ImageWithFallback';

interface Step1ServiceSelectProps {
  services: Service[];
  selectedService: Service | null;
  onSelect: (service: Service) => void;
  onNext: () => void;
}

export const Step1ServiceSelect: React.FC<Step1ServiceSelectProps> = ({
  services,
  selectedService,
  onSelect,
  onNext,
}) => {
  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="text-center max-w-xl mx-auto">
        <h3 className="text-xl font-bold text-slate-900">Step 1: Choose Your Dental Service</h3>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Select the treatment you wish to receive. Each service includes dedicated time with our dental team.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {services.map((service) => {
          const isSelected = selectedService?.id === service.id;
          const img = getServiceImage(service.name);

          return (
            <div
              key={service.id}
              onClick={() => onSelect(service)}
              className={`rounded-2xl p-4 cursor-pointer transition-all duration-200 border-2 relative flex flex-col justify-between ${
                isSelected
                  ? 'border-teal-600 bg-teal-50/40 shadow-md shadow-teal-700/10'
                  : 'border-slate-200/80 bg-white hover:border-teal-300 hover:bg-slate-50/50'
              }`}
            >
              {isSelected && (
                <div className="absolute top-3 right-3 w-6 h-6 rounded-full bg-teal-600 text-white flex items-center justify-center shadow-xs z-10">
                  <Check className="w-3.5 h-3.5" />
                </div>
              )}

              <div className="space-y-3">
                <div className="h-28 rounded-xl overflow-hidden relative">
                  <ImageWithFallback
                    src={img.url}
                    alt={img.alt}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-2 left-2 bg-slate-950/70 text-white text-[11px] font-semibold px-2.5 py-0.5 rounded-md flex items-center gap-1">
                    <Clock className="w-3 h-3 text-teal-400" />
                    <span>{service.duration_minutes} mins</span>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{service.name}</h4>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">{service.description}</p>
                </div>
              </div>

              <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">Treatment Fee</span>
                <span className="text-sm font-extrabold text-teal-700">
                  ${Number(service.price).toFixed(2)}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex justify-end pt-4 border-t border-slate-100">
        <button
          id="step1-next-btn"
          disabled={!selectedService}
          onClick={onNext}
          className="inline-flex items-center gap-2 px-6 py-3 bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold rounded-xl shadow-md transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer active:scale-95"
        >
          <span>Continue to Date Selection</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
