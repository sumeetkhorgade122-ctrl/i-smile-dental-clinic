import React, { useState, useEffect } from 'react';
import { useClinic } from '../../../context/ClinicContext';
import { Service, TimeSlot, Appointment } from '../../../types/database';
import { Step1ServiceSelect } from './Step1ServiceSelect';
import { Step2DateSelect } from './Step2DateSelect';
import { Step3TimeSelect } from './Step3TimeSelect';
import { Step4PatientDetails, PatientFormData } from './Step4PatientDetails';
import { Step5Summary } from './Step5Summary';
import { Step6Success } from './Step6Success';
import { appointmentService } from '../../../services/appointmentService';
import { Check, Sparkles } from 'lucide-react';

interface BookingFlowProps {
  preSelectedService?: Service | null;
  onClearPreSelected?: () => void;
}

export const BookingFlow: React.FC<BookingFlowProps> = ({
  preSelectedService,
  onClearPreSelected,
}) => {
  const { activeServices, businessHours, blockedDates, settings } = useClinic();

  const [currentStep, setCurrentStep] = useState<number>(1);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedSlot, setSelectedSlot] = useState<TimeSlot | null>(null);
  const [patientData, setPatientData] = useState<PatientFormData>({
    full_name: '',
    email: '',
    phone: '',
    notes: '',
  });

  const [submitting, setSubmitting] = useState<boolean>(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [createdAppointment, setCreatedAppointment] = useState<Appointment | null>(null);

  // If a service was pre-selected from the Services section, set it and advance to step 2
  useEffect(() => {
    if (preSelectedService) {
      setSelectedService(preSelectedService);
      setCurrentStep(2);
      if (onClearPreSelected) onClearPreSelected();
    }
  }, [preSelectedService, onClearPreSelected]);

  const handleReset = () => {
    setCurrentStep(1);
    setSelectedService(null);
    setSelectedDate('');
    setSelectedSlot(null);
    setPatientData({ full_name: '', email: '', phone: '', notes: '' });
    setCreatedAppointment(null);
    setSubmitError(null);
  };

  const handleFinalSubmit = async () => {
    if (!selectedService || !selectedDate || !selectedSlot) return;

    try {
      setSubmitting(true);
      setSubmitError(null);

      const appt = await appointmentService.createAppointment({
        full_name: patientData.full_name,
        email: patientData.email,
        phone: patientData.phone,
        service_id: selectedService.id,
        appointment_date: selectedDate,
        start_time: selectedSlot.formattedStartTime,
        end_time: selectedSlot.formattedEndTime,
        notes: patientData.notes,
      });

      setCreatedAppointment(appt);
      setCurrentStep(6);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unable to reserve appointment. Please try again.';
      setSubmitError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const stepLabels = ['Select Service', 'Pick Date', 'Choose Time', 'Patient Info', 'Confirm'];

  return (
    <section className="py-20 bg-gradient-to-b from-slate-50 to-white border-t border-slate-200/80" id="booking">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-teal-700 block mb-2">
            Real-Time Availability
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Reserve Your Dental Visit
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-2">
            Select a service, view live available slots, and book in under 2 minutes. No hidden steps or phone delays.
          </p>
        </div>

        {/* Step Progress Bar (Steps 1 to 5) */}
        {currentStep < 6 && (
          <div className="mb-10 max-w-3xl mx-auto">
            <div className="flex items-center justify-between relative">
              {/* Connecting line */}
              <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-200 -translate-y-1/2 -z-0" />
              <div
                className="absolute top-1/2 left-0 h-0.5 bg-teal-600 -translate-y-1/2 -z-0 transition-all duration-300"
                style={{ width: `${((currentStep - 1) / 4) * 100}%` }}
              />

              {stepLabels.map((label, index) => {
                const stepNum = index + 1;
                const isCompleted = currentStep > stepNum;
                const isCurrent = currentStep === stepNum;

                return (
                  <div key={label} className="flex flex-col items-center relative z-10">
                    <button
                      type="button"
                      disabled={stepNum > currentStep}
                      onClick={() => {
                        if (stepNum < currentStep) setCurrentStep(stepNum);
                      }}
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all duration-200 ${
                        isCompleted
                          ? 'bg-teal-700 text-white shadow-xs cursor-pointer'
                          : isCurrent
                          ? 'bg-teal-600 text-white ring-4 ring-teal-100 shadow-md scale-110'
                          : 'bg-white text-slate-400 border-2 border-slate-300 cursor-not-allowed'
                      }`}
                    >
                      {isCompleted ? <Check className="w-4 h-4" /> : stepNum}
                    </button>
                    <span
                      className={`text-[10px] sm:text-xs font-semibold mt-1.5 hidden sm:block ${
                        isCurrent ? 'text-teal-900 font-bold' : isCompleted ? 'text-slate-700' : 'text-slate-400'
                      }`}
                    >
                      {label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Dynamic Step View */}
        <div className="bg-slate-50/70 p-4 sm:p-8 rounded-3xl border border-slate-200 shadow-xs">
          {currentStep === 1 && (
            <Step1ServiceSelect
              services={activeServices}
              selectedService={selectedService}
              onSelect={(srv) => setSelectedService(srv)}
              onNext={() => setCurrentStep(2)}
            />
          )}

          {currentStep === 2 && (
            <Step2DateSelect
              selectedDate={selectedDate}
              onSelectDate={(date) => setSelectedDate(date)}
              onNext={() => setCurrentStep(3)}
              onBack={() => setCurrentStep(1)}
              businessHours={businessHours}
              blockedDates={blockedDates}
              clinicSettings={settings}
            />
          )}

          {currentStep === 3 && selectedService && (
            <Step3TimeSelect
              service={selectedService}
              selectedDate={selectedDate}
              selectedSlot={selectedSlot}
              onSelectSlot={(slot) => setSelectedSlot(slot)}
              onNext={() => setCurrentStep(4)}
              onBack={() => setCurrentStep(2)}
              businessHours={businessHours}
              blockedDates={blockedDates}
              clinicSettings={settings}
            />
          )}

          {currentStep === 4 && (
            <Step4PatientDetails
              formData={patientData}
              onChange={(data) => setPatientData(data)}
              onNext={() => setCurrentStep(5)}
              onBack={() => setCurrentStep(3)}
            />
          )}

          {currentStep === 5 && selectedService && selectedSlot && (
            <Step5Summary
              clinicSettings={settings}
              service={selectedService}
              selectedDate={selectedDate}
              selectedSlot={selectedSlot}
              patientData={patientData}
              onBack={() => setCurrentStep(4)}
              onSubmit={handleFinalSubmit}
              submitting={submitting}
              submitError={submitError}
            />
          )}

          {currentStep === 6 && createdAppointment && selectedService && selectedSlot && (
            <Step6Success
              appointment={createdAppointment}
              service={selectedService}
              selectedDate={selectedDate}
              selectedSlot={selectedSlot}
              clinicSettings={settings}
              onReset={handleReset}
            />
          )}
        </div>
      </div>
    </section>
  );
};
