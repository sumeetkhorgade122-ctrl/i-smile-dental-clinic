import React, { useMemo } from 'react';
import { BusinessHour, BlockedDate, ClinicSettings } from '../../../types/database';
import { formatDateToIso, getDayOfWeek } from '../../../utils/dateTime';
import { isDateBlocked, isDateClosed } from '../../../utils/availability';
import { ArrowLeft, ArrowRight, Calendar as CalendarIcon, CheckCircle2, AlertCircle } from 'lucide-react';

interface Step2DateSelectProps {
  selectedDate: string; // YYYY-MM-DD
  onSelectDate: (date: string) => void;
  onNext: () => void;
  onBack: () => void;
  businessHours: BusinessHour[];
  blockedDates: BlockedDate[];
  clinicSettings: ClinicSettings;
}

export const Step2DateSelect: React.FC<Step2DateSelectProps> = ({
  selectedDate,
  onSelectDate,
  onNext,
  onBack,
  businessHours,
  blockedDates,
  clinicSettings,
}) => {
  // Generate the next 28 days
  const dateOptions = useMemo(() => {
    const today = new Date();
    const days = [];

    for (let i = 0; i < 28; i++) {
      const d = new Date();
      d.setDate(today.getDate() + i);
      const iso = formatDateToIso(d);
      const isBlocked = isDateBlocked(iso, blockedDates);
      const isClosed = isDateClosed(iso, businessHours);

      // Check if today has passed notice hours
      const isToday = i === 0;
      let blockedByNotice = false;
      if (isToday) {
        const dayOfWeek = getDayOfWeek(iso);
        const todayHours = businessHours.find((bh) => bh.weekday === dayOfWeek);
        if (todayHours && todayHours.is_open) {
          const parts = todayHours.end_time.split(':').map(Number);
          const closingTime = new Date(d.getFullYear(), d.getMonth(), d.getDate(), parts[0], parts[1] || 0);
          const earliestTime = new Date(Date.now() + (clinicSettings.booking_notice_hours || 0) * 3600000);
          if (earliestTime >= closingTime) {
            blockedByNotice = true;
          }
        }
      }

      const isValid = !isBlocked && !isClosed && !blockedByNotice;

      days.push({
        date: d,
        iso,
        dayNumber: d.getDate(),
        dayName: d.toLocaleDateString('en-US', { weekday: 'short' }),
        monthName: d.toLocaleDateString('en-US', { month: 'short' }),
        isValid,
        isBlocked,
        isClosed,
        isToday,
        reason: isBlocked
          ? blockedDates.find((b) => b.blocked_date === iso)?.reason || 'Unavailable'
          : isClosed
          ? 'Clinic Closed'
          : blockedByNotice
          ? 'Notice Period Passed'
          : 'Available',
      });
    }
    return days;
  }, [businessHours, blockedDates, clinicSettings]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="text-center max-w-xl mx-auto">
        <h3 className="text-xl font-bold text-slate-900">Step 2: Choose Your Appointment Date</h3>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Select an available day for your dental consultation. Non-operational days and holidays are automatically unavailable.
        </p>
      </div>

      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-2 mb-4 text-xs font-semibold text-slate-600">
          <CalendarIcon className="w-4 h-4 text-teal-600" />
          <span>Next 4 Weeks Available Calendar</span>
        </div>

        {/* Date Tiles Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
          {dateOptions.map((item) => {
            const isSelected = selectedDate === item.iso;

            return (
              <button
                key={item.iso}
                type="button"
                disabled={!item.isValid}
                onClick={() => onSelectDate(item.iso)}
                id={`date-tile-${item.iso}`}
                className={`p-3 rounded-xl flex flex-col items-center justify-between text-center transition-all duration-200 relative border ${
                  isSelected
                    ? 'bg-teal-700 text-white border-teal-700 shadow-md scale-102 ring-2 ring-teal-500/30'
                    : item.isValid
                    ? 'bg-slate-50 hover:bg-teal-50/70 hover:border-teal-300 text-slate-900 border-slate-200/70 cursor-pointer'
                    : 'bg-slate-100/60 text-slate-400 border-slate-100 cursor-not-allowed opacity-60'
                }`}
              >
                <span
                  className={`text-[10px] font-bold uppercase tracking-wider ${
                    isSelected ? 'text-teal-100' : 'text-slate-500'
                  }`}
                >
                  {item.dayName}
                </span>
                <span className="text-lg font-black my-1 font-mono">{item.dayNumber}</span>
                <span
                  className={`text-[10px] font-semibold ${
                    isSelected
                      ? 'text-teal-100'
                      : item.isValid
                      ? 'text-teal-700'
                      : 'text-slate-400'
                  }`}
                >
                  {item.monthName}
                </span>

                {item.isToday && (
                  <span
                    className={`mt-1 text-[9px] px-1.5 py-0.2 rounded-full font-bold uppercase ${
                      isSelected ? 'bg-teal-800 text-white' : 'bg-teal-100 text-teal-800'
                    }`}
                  >
                    Today
                  </span>
                )}

                {!item.isValid && (
                  <span className="mt-1 text-[9px] text-slate-400 block truncate max-w-full">
                    {item.reason}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-4 mt-6 pt-4 border-t border-slate-100 text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-teal-50 border border-teal-500" />
            <span>Available</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-teal-700" />
            <span>Selected</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-slate-200" />
            <span>Closed / Blocked</span>
          </div>
        </div>
      </div>

      <div className="flex justify-between pt-4 border-t border-slate-100">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-slate-700 hover:bg-slate-100 rounded-xl text-sm font-semibold transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Services</span>
        </button>

        <button
          id="step2-next-btn"
          type="button"
          disabled={!selectedDate}
          onClick={onNext}
          className="inline-flex items-center gap-2 px-6 py-3 bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold rounded-xl shadow-md transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer active:scale-95"
        >
          <span>Select Time Slot</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
