import React from 'react';
import { ShieldCheck, HeartHandshake, Microscope, Sparkles, Smile, Award } from 'lucide-react';

export const TrustSection: React.FC = () => {
  const highlights = [
    {
      icon: HeartHandshake,
      title: 'Gentle, Patient-First Philosophy',
      description:
        'Every appointment begins with listening. We explain every step beforehand and customize your pace for a truly anxiety-free visit.',
    },
    {
      icon: Microscope,
      title: 'Digital Precision Technology',
      description:
        'Equipped with ultra-low radiation digital radiography, intraoral high-def scanning, and precision biomimetic restoration.',
    },
    {
      icon: ShieldCheck,
      title: 'Hospital-Grade Cleanliness',
      description:
        'Multi-stage autoclave sterilization of all instruments, sterile treatment suites, and continuous HEPA air filtration throughout.',
    },
    {
      icon: Sparkles,
      title: 'Transparent Care & Upfront Fees',
      description:
        'Clear treatment plans with zero hidden charges. We review all options, insurance estimates, and fees before commencing care.',
    },
  ];

  return (
    <section className="py-16 bg-white border-y border-slate-100" id="trust-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-xs font-bold uppercase tracking-widest text-teal-700 mb-2">
            The I Smile Standard
          </h2>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Healthcare Built on Trust, Comfort &amp; Clinical Excellence
          </p>
          <p className="text-sm sm:text-base text-slate-600 mt-2.5">
            We believe dental visits should feel calming and empowering. Here is why our patients trust us with their smile care year after year.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {highlights.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="bg-[#F8FAFC] rounded-2xl p-6 border border-slate-100/90 hover:border-teal-200 hover:shadow-md transition-all duration-200 group flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-white text-teal-700 border border-slate-200/60 shadow-xs flex items-center justify-center mb-4 group-hover:scale-105 group-hover:bg-teal-700 group-hover:text-white transition-all duration-200">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2">{item.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
