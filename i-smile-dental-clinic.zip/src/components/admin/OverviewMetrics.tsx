import React from 'react';
import { Appointment, Service } from '../../types/database';
import { formatDateToIso } from '../../utils/dateTime';
import { Calendar, Clock, AlertCircle, CheckCircle2, Sparkles, Activity, Users, ArrowUpRight } from 'lucide-react';

interface OverviewMetricsProps {
  appointments: Appointment[];
  services: Service[];
  onGoToAppointments: (filter?: string) => void;
  onGoToServices: () => void;
}

export const OverviewMetrics: React.FC<OverviewMetricsProps> = ({
  appointments,
  services,
  onGoToAppointments,
  onGoToServices,
}) => {
  const todayIso = formatDateToIso(new Date());

  // Real calculations directly from Supabase appointments array
  const totalAppointments = appointments.length;
  const todayAppointments = appointments.filter((a) => a.appointment_date === todayIso && a.status !== 'cancelled');
  const pendingAppointments = appointments.filter((a) => a.status === 'pending');
  const confirmedAppointments = appointments.filter((a) => a.status === 'confirmed');
  const completedAppointments = appointments.filter((a) => a.status === 'completed');
  const activeServices = services.filter((s) => s.is_active);

  const statCards = [
    {
      title: "Today's Schedule",
      value: todayAppointments.length,
      subtitle: `${todayAppointments.filter(a => a.status === 'confirmed').length} confirmed for today`,
      icon: Clock,
      color: 'text-teal-700',
      bgColor: 'bg-teal-50',
      action: () => onGoToAppointments('all'),
    },
    {
      title: 'Pending Requests',
      value: pendingAppointments.length,
      subtitle: 'Require clinic staff review',
      icon: AlertCircle,
      color: 'text-amber-700',
      bgColor: 'bg-amber-50',
      action: () => onGoToAppointments('pending'),
    },
    {
      title: 'Total Appointments',
      value: totalAppointments,
      subtitle: `${confirmedAppointments.length} confirmed • ${completedAppointments.length} completed`,
      icon: Calendar,
      color: 'text-indigo-700',
      bgColor: 'bg-indigo-50',
      action: () => onGoToAppointments('all'),
    },
    {
      title: 'Active Dental Services',
      value: activeServices.length,
      subtitle: `${services.length - activeServices.length} inactive in catalog`,
      icon: Sparkles,
      color: 'text-cyan-700',
      bgColor: 'bg-cyan-50',
      action: onGoToServices,
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Page Title */}
      <div>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Clinic Operational Overview</h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Real-time metrics computed directly from Supabase appointments and services records.
        </p>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={index}
              onClick={card.action}
              className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs hover:shadow-md hover:border-teal-300 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">{card.title}</span>
                <div className={`w-9 h-9 rounded-xl ${card.bgColor} ${card.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <Icon className="w-5 h-5" />
                </div>
              </div>

              <div>
                <div className="text-3xl font-black text-slate-900 font-mono tracking-tight">{card.value}</div>
                <p className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
                  <span>{card.subtitle}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-teal-600 transition-colors" />
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Today's Agenda & Urgent Action lists */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Today's appointments preview */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-600" />
              <h3 className="font-bold text-slate-900 text-sm">Today&apos;s Appointments ({todayAppointments.length})</h3>
            </div>
            <button
              onClick={() => onGoToAppointments('all')}
              className="text-xs font-semibold text-teal-700 hover:text-teal-900 underline cursor-pointer"
            >
              View All
            </button>
          </div>

          {todayAppointments.length === 0 ? (
            <div className="py-10 text-center text-slate-400 text-xs">
              No appointments scheduled for today.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {todayAppointments.slice(0, 5).map((appt) => (
                <div key={appt.id} className="py-3 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-900 block">{appt.full_name}</span>
                    <span className="text-slate-500 text-[11px]">
                      {appt.service?.name || 'Dental Service'} • {appt.start_time.substring(0, 5)} - {appt.end_time.substring(0, 5)}
                    </span>
                  </div>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      appt.status === 'confirmed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : appt.status === 'pending'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-slate-100 text-slate-800'
                    }`}
                  >
                    {appt.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pending Requests Requiring Approval */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600" />
              <h3 className="font-bold text-slate-900 text-sm">Awaiting Review ({pendingAppointments.length})</h3>
            </div>
            <button
              onClick={() => onGoToAppointments('pending')}
              className="text-xs font-semibold text-amber-700 hover:text-amber-900 underline cursor-pointer"
            >
              Review All
            </button>
          </div>

          {pendingAppointments.length === 0 ? (
            <div className="py-10 text-center text-slate-400 text-xs">
              All appointments have been confirmed or completed.
            </div>
          ) : (
            <div className="space-y-3">
              {pendingAppointments.slice(0, 4).map((appt) => (
                <div key={appt.id} className="p-3 rounded-xl bg-amber-50/50 border border-amber-200/60 text-xs flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900 block">{appt.full_name}</span>
                    <span className="text-slate-500 text-[11px]">
                      {appt.appointment_date} at {appt.start_time.substring(0, 5)}
                    </span>
                  </div>
                  <button
                    onClick={() => onGoToAppointments('pending')}
                    className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-lg text-[10px] cursor-pointer"
                  >
                    Review
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
