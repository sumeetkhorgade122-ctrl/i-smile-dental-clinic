import React, { useState } from 'react';
import { Appointment, AppointmentStatus } from '../../types/database';
import { appointmentService } from '../../services/appointmentService';
import { formatDateForDisplay, formatTimeRangeForDisplay } from '../../utils/dateTime';
import { Modal } from '../common/Modal';
import {
  Calendar,
  Clock,
  User,
  Mail,
  Phone,
  Search,
  Filter,
  Eye,
  CheckCircle2,
  XCircle,
  Clock3,
  CheckCheck,
  AlertCircle,
} from 'lucide-react';

interface AppointmentsManagerProps {
  appointments: Appointment[];
  onRefresh: () => void;
  initialFilter?: string;
}

export const AppointmentsManager: React.FC<AppointmentsManagerProps> = ({
  appointments,
  onRefresh,
  initialFilter = 'all',
}) => {
  const [statusFilter, setStatusFilter] = useState<string>(initialFilter);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [selectedAppt, setSelectedAppt] = useState<Appointment | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [updateError, setUpdateError] = useState<string | null>(null);

  const handleStatusChange = async (id: string, newStatus: AppointmentStatus) => {
    try {
      setUpdatingId(id);
      setUpdateError(null);
      await appointmentService.updateAppointmentStatus(id, newStatus);
      if (selectedAppt && selectedAppt.id === id) {
        setSelectedAppt({ ...selectedAppt, status: newStatus });
      }
      onRefresh();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unable to update status';
      setUpdateError(msg);
    } finally {
      setUpdatingId(null);
    }
  };

  // Filter & Search Logic
  const filteredAppointments = appointments.filter((appt) => {
    if (statusFilter !== 'all' && appt.status !== statusFilter) return false;
    if (dateFilter && appt.appointment_date !== dateFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchesName = appt.full_name?.toLowerCase().includes(q);
      const matchesEmail = appt.email?.toLowerCase().includes(q);
      const matchesPhone = appt.phone?.includes(q);
      const matchesService = appt.service?.name?.toLowerCase().includes(q);
      if (!matchesName && !matchesEmail && !matchesPhone && !matchesService) return false;
    }
    return true;
  });

  const getStatusBadge = (status: AppointmentStatus) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-0.5 rounded-full text-xs font-semibold">
            <CheckCircle2 className="w-3 h-3" /> Confirmed
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-0.5 rounded-full text-xs font-semibold">
            <Clock3 className="w-3 h-3" /> Pending
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 bg-blue-50 text-blue-700 border border-blue-200 px-2.5 py-0.5 rounded-full text-xs font-semibold">
            <CheckCheck className="w-3 h-3" /> Completed
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 border border-rose-200 px-2.5 py-0.5 rounded-full text-xs font-semibold">
            <XCircle className="w-3 h-3" /> Cancelled
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Appointments Management</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            View, approve, and track all patient dental bookings. Total: {appointments.length}
          </p>
        </div>

        {/* Status Filter Tabs */}
        <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-xl text-xs font-medium self-start md:self-auto overflow-x-auto">
          {['all', 'pending', 'confirmed', 'completed', 'cancelled'].map((tab) => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`px-3 py-1.5 rounded-lg capitalize transition-all cursor-pointer ${
                statusFilter === tab
                  ? 'bg-white text-slate-900 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Search and Date Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search patient, email, phone..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="flex items-center gap-2 text-xs text-slate-500 w-full sm:w-auto">
            <span>Filter Date:</span>
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            />
            {dateFilter && (
              <button
                onClick={() => setDateFilter('')}
                className="text-xs text-slate-400 hover:text-slate-600 underline"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      </div>

      {updateError && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600" />
          <span>{updateError}</span>
        </div>
      )}

      {/* Appointments Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50/80 border-b border-slate-200 text-[11px] uppercase font-bold text-slate-500 tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Patient</th>
                <th className="py-3.5 px-4">Service</th>
                <th className="py-3.5 px-4">Date &amp; Time</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAppointments.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    No appointments matching current filters.
                  </td>
                </tr>
              ) : (
                filteredAppointments.map((appt) => (
                  <tr key={appt.id} className="hover:bg-slate-50/60 transition-colors">
                    {/* Patient */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{appt.full_name}</div>
                      <div className="text-slate-400 text-[11px]">{appt.phone}</div>
                    </td>

                    {/* Service */}
                    <td className="py-3.5 px-4 font-medium text-slate-800">
                      {appt.service?.name || 'Dental Consultation'}
                    </td>

                    {/* Date & Time */}
                    <td className="py-3.5 px-4 font-mono">
                      <div className="font-semibold text-slate-900">
                        {formatDateForDisplay(appt.appointment_date)}
                      </div>
                      <div className="text-slate-500 text-[11px]">
                        {formatTimeRangeForDisplay(appt.start_time, appt.end_time)}
                      </div>
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4">{getStatusBadge(appt.status)}</td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          id={`view-appt-${appt.id}`}
                          onClick={() => setSelectedAppt(appt)}
                          className="p-1.5 text-slate-500 hover:text-teal-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {appt.status === 'pending' && (
                          <button
                            id={`confirm-appt-${appt.id}`}
                            disabled={updatingId === appt.id}
                            onClick={() => handleStatusChange(appt.id, 'confirmed')}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-semibold transition-colors disabled:opacity-50 cursor-pointer"
                          >
                            Confirm
                          </button>
                        )}

                        {appt.status === 'confirmed' && (
                          <button
                            id={`complete-appt-${appt.id}`}
                            disabled={updatingId === appt.id}
                            onClick={() => handleStatusChange(appt.id, 'completed')}
                            className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[11px] font-semibold transition-colors disabled:opacity-50 cursor-pointer"
                          >
                            Complete
                          </button>
                        )}

                        {appt.status !== 'cancelled' && appt.status !== 'completed' && (
                          <button
                            id={`cancel-appt-${appt.id}`}
                            disabled={updatingId === appt.id}
                            onClick={() => handleStatusChange(appt.id, 'cancelled')}
                            className="px-2 py-1 text-rose-600 hover:bg-rose-50 rounded-lg text-[11px] font-medium transition-colors disabled:opacity-50 cursor-pointer"
                          >
                            Cancel
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Appointment Detail Modal */}
      {selectedAppt && (
        <Modal
          isOpen={Boolean(selectedAppt)}
          onClose={() => setSelectedAppt(null)}
          title="Appointment Record"
          subtitle={`Reference ID: ${selectedAppt.id}`}
          maxWidth="max-w-xl"
        >
          <div className="space-y-6">
            {/* Status & Service Highlight */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between flex-wrap gap-2">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400">Treatment</span>
                <p className="font-bold text-slate-900 text-sm">
                  {selectedAppt.service?.name || 'Dental Service'}
                </p>
                {selectedAppt.service?.duration_minutes && (
                  <p className="text-xs text-slate-500">
                    Duration: {selectedAppt.service.duration_minutes} mins • Fee: ${Number(selectedAppt.service.price).toFixed(2)}
                  </p>
                )}
              </div>
              <div>{getStatusBadge(selectedAppt.status)}</div>
            </div>

            {/* Date & Time */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-teal-50/50 rounded-xl border border-teal-100">
                <span className="text-[10px] font-bold text-teal-800 uppercase block">Date</span>
                <p className="font-bold text-slate-900 text-xs mt-0.5">
                  {formatDateForDisplay(selectedAppt.appointment_date)}
                </p>
              </div>
              <div className="p-3 bg-teal-50/50 rounded-xl border border-teal-100">
                <span className="text-[10px] font-bold text-teal-800 uppercase block">Time</span>
                <p className="font-bold text-slate-900 text-xs mt-0.5 font-mono">
                  {formatTimeRangeForDisplay(selectedAppt.start_time, selectedAppt.end_time)}
                </p>
              </div>
            </div>

            {/* Patient Info */}
            <div className="space-y-3 pt-2 border-t border-slate-100 text-xs">
              <h4 className="font-bold text-slate-900 uppercase text-[11px] tracking-wider">
                Patient Contact Information
              </h4>
              <div className="space-y-2 text-slate-700">
                <p className="flex items-center gap-2">
                  <User className="w-4 h-4 text-slate-400" />
                  <strong>Name:</strong> {selectedAppt.full_name}
                </p>
                <p className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-slate-400" />
                  <strong>Email:</strong>{' '}
                  <a href={`mailto:${selectedAppt.email}`} className="text-teal-700 underline">
                    {selectedAppt.email}
                  </a>
                </p>
                <p className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-slate-400" />
                  <strong>Phone:</strong>{' '}
                  <a href={`tel:${selectedAppt.phone}`} className="text-teal-700 underline">
                    {selectedAppt.phone}
                  </a>
                </p>
              </div>
            </div>

            {/* Patient Notes */}
            {selectedAppt.notes && (
              <div className="pt-2 border-t border-slate-100">
                <span className="text-[11px] font-bold text-slate-500 block mb-1">
                  Patient Notes &amp; Concerns:
                </span>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 leading-relaxed italic">
                  &ldquo;{selectedAppt.notes}&rdquo;
                </div>
              </div>
            )}

            {/* Quick Status Action Buttons */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
              <span className="text-xs font-semibold text-slate-500">Change Status:</span>
              <div className="flex items-center gap-2">
                {selectedAppt.status !== 'confirmed' && selectedAppt.status !== 'completed' && (
                  <button
                    disabled={updatingId === selectedAppt.id}
                    onClick={() => handleStatusChange(selectedAppt.id, 'confirmed')}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                  >
                    Mark Confirmed
                  </button>
                )}

                {selectedAppt.status !== 'completed' && (
                  <button
                    disabled={updatingId === selectedAppt.id}
                    onClick={() => handleStatusChange(selectedAppt.id, 'completed')}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                  >
                    Mark Completed
                  </button>
                )}

                {selectedAppt.status !== 'cancelled' && (
                  <button
                    disabled={updatingId === selectedAppt.id}
                    onClick={() => handleStatusChange(selectedAppt.id, 'cancelled')}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                  >
                    Mark Cancelled
                  </button>
                )}
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
