import React, { useState } from 'react';
import { BusinessHour, ClinicSettings } from '../../types/database';
import { weekdayNames } from '../../data/defaultData';
import { clinicService } from '../../services/clinicService';
import { Clock, Check, AlertCircle, Save, Sliders, ShieldCheck } from 'lucide-react';

interface BusinessHoursManagerProps {
  businessHours: BusinessHour[];
  clinicSettings: ClinicSettings;
  onRefresh: () => void;
}

export const BusinessHoursManager: React.FC<BusinessHoursManagerProps> = ({
  businessHours,
  clinicSettings,
  onRefresh,
}) => {
  const [hoursState, setHoursState] = useState<BusinessHour[]>([...businessHours]);
  const [slotInterval, setSlotInterval] = useState<number>(clinicSettings.slot_interval_minutes || 30);
  const [noticeHours, setNoticeHours] = useState<number>(clinicSettings.booking_notice_hours || 2);

  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Keep hours sorted from Monday (1) to Sunday (0)
  const sortedIndices = [1, 2, 3, 4, 5, 6, 0];

  const handleToggleDay = (weekday: number) => {
    setHoursState((prev) =>
      prev.map((bh) => (bh.weekday === weekday ? { ...bh, is_open: !bh.is_open } : bh))
    );
  };

  const handleTimeChange = (weekday: number, field: 'start_time' | 'end_time', value: string) => {
    setHoursState((prev) =>
      prev.map((bh) => (bh.weekday === weekday ? { ...bh, [field]: value } : bh))
    );
  };

  const handleSaveAll = async () => {
    try {
      setSaving(true);
      setSaveSuccess(false);
      setSaveError(null);

      // 1. Save all updated business hours
      for (const bh of hoursState) {
        if (bh.id) {
          await clinicService.updateBusinessHour(bh.id, {
            is_open: bh.is_open,
            start_time: bh.start_time,
            end_time: bh.end_time,
          });
        }
      }

      // 2. Save slot interval and notice hours in clinic_settings
      if (clinicSettings.id) {
        await clinicService.updateClinicSettings(clinicSettings.id, {
          slot_interval_minutes: Number(slotInterval),
          booking_notice_hours: Number(noticeHours),
        });
      }

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
      onRefresh();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unable to update schedule';
      setSaveError(msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Business Hours &amp; Scheduling Engine</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Configure weekly operating hours, appointment interval increments, and required patient advance booking notice.
          </p>
        </div>

        <button
          id="btn-save-schedule"
          disabled={saving}
          onClick={handleSaveAll}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer disabled:opacity-50 self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'Saving Schedule...' : 'Save Schedule Changes'}</span>
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2 font-medium">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>Operating hours and slot parameters updated successfully in Supabase!</span>
        </div>
      )}

      {saveError && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600" />
          <span>{saveError}</span>
        </div>
      )}

      {/* Global Booking Engine Parameters */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-2 mb-4 text-xs font-bold uppercase tracking-wider text-slate-700">
          <Sliders className="w-4 h-4 text-teal-600" />
          <span>Appointment Engine Configuration</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Slot Grid Interval (Minutes)
            </label>
            <p className="text-[11px] text-slate-400 mb-2">
              The time increments between possible appointment start times (e.g. every 15, 30, or 60 mins).
            </p>
            <select
              value={slotInterval}
              onChange={(e) => setSlotInterval(Number(e.target.value))}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="15">15 Minutes</option>
              <option value="20">20 Minutes</option>
              <option value="30">30 Minutes (Recommended)</option>
              <option value="45">45 Minutes</option>
              <option value="60">60 Minutes</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Minimum Advance Booking Notice (Hours)
            </label>
            <p className="text-[11px] text-slate-400 mb-2">
              Prevents walk-in bookings without sufficient prep time (e.g. minimum 2 hours advance notice).
            </p>
            <select
              value={noticeHours}
              onChange={(e) => setNoticeHours(Number(e.target.value))}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            >
              <option value="0">0 Hours (Immediate Booking)</option>
              <option value="1">1 Hour in Advance</option>
              <option value="2">2 Hours in Advance</option>
              <option value="4">4 Hours in Advance</option>
              <option value="12">12 Hours in Advance</option>
              <option value="24">24 Hours in Advance</option>
            </select>
          </div>
        </div>
      </div>

      {/* Days Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700">
            <Clock className="w-4 h-4 text-teal-600" />
            <span>Weekly Operating Hours</span>
          </div>
          <span className="text-[11px] text-slate-400">Available slots are only generated during open periods</span>
        </div>

        <div className="divide-y divide-slate-100">
          {sortedIndices.map((weekday) => {
            const bh = hoursState.find((h) => h.weekday === weekday) || {
              weekday,
              is_open: false,
              start_time: '09:00:00',
              end_time: '17:00:00',
            };
            const name = weekdayNames[weekday];

            return (
              <div
                key={weekday}
                className={`p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  bh.is_open ? 'bg-white' : 'bg-slate-50/70 opacity-75'
                }`}
              >
                <div className="w-40 flex items-center gap-3">
                  <input
                    type="checkbox"
                    id={`open-toggle-${weekday}`}
                    checked={bh.is_open}
                    onChange={() => handleToggleDay(weekday)}
                    className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                  />
                  <label
                    htmlFor={`open-toggle-${weekday}`}
                    className={`text-xs font-bold cursor-pointer ${
                      bh.is_open ? 'text-slate-900' : 'text-slate-400 line-through'
                    }`}
                  >
                    {name}
                  </label>
                </div>

                <div className="flex items-center gap-3">
                  {bh.is_open ? (
                    <div className="flex items-center gap-2 text-xs text-slate-600">
                      <span>Open:</span>
                      <input
                        type="time"
                        value={bh.start_time.substring(0, 5)}
                        onChange={(e) => handleTimeChange(weekday, 'start_time', `${e.target.value}:00`)}
                        className="py-1 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                      />
                      <span>to</span>
                      <input
                        type="time"
                        value={bh.end_time.substring(0, 5)}
                        onChange={(e) => handleTimeChange(weekday, 'end_time', `${e.target.value}:00`)}
                        className="py-1 px-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                      />
                    </div>
                  ) : (
                    <span className="text-xs text-slate-400 italic">Clinic Closed</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
