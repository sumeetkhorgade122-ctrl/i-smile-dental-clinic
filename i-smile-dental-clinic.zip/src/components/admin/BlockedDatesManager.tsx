import React, { useState } from 'react';
import { BlockedDate } from '../../types/database';
import { clinicService } from '../../services/clinicService';
import { formatDateForDisplay } from '../../utils/dateTime';
import { CalendarX, Plus, Trash2, AlertCircle, CheckCircle2 } from 'lucide-react';

interface BlockedDatesManagerProps {
  blockedDates: BlockedDate[];
  onRefresh: () => void;
}

export const BlockedDatesManager: React.FC<BlockedDatesManagerProps> = ({
  blockedDates,
  onRefresh,
}) => {
  const [newDate, setNewDate] = useState('');
  const [newReason, setNewReason] = useState('');
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAddBlockedDate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDate) {
      setError('Please select a date to block');
      return;
    }

    try {
      setAdding(true);
      setError(null);
      await clinicService.addBlockedDate(newDate, newReason.trim() || 'Clinic Closed / Holiday');
      setNewDate('');
      setNewReason('');
      onRefresh();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unable to block date';
      setError(msg);
    } finally {
      setAdding(false);
    }
  };

  const handleDeleteBlockedDate = async (id: string) => {
    try {
      await clinicService.deleteBlockedDate(id);
      onRefresh();
    } catch (err: unknown) {
      console.error('Error removing blocked date:', err);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Blocked Dates &amp; Holidays</h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
          Mark specific calendar dates as unavailable for patient bookings (holidays, staff training, clinic maintenance).
        </p>
      </div>

      {error && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600" />
          <span>{error}</span>
        </div>
      )}

      {/* Add Blocked Date Form */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
          <CalendarX className="w-4 h-4 text-teal-600" />
          <span>Block a New Calendar Date</span>
        </h3>

        <form onSubmit={handleAddBlockedDate} className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
          <div className="sm:col-span-4">
            <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
              Select Date <span className="text-rose-500">*</span>
            </label>
            <input
              type="date"
              required
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            />
          </div>

          <div className="sm:col-span-6">
            <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
              Reason / Public Notice (e.g. National Holiday, Staff Retreat)
            </label>
            <input
              type="text"
              placeholder="e.g. Labor Day / Clinic Maintenance"
              value={newReason}
              onChange={(e) => setNewReason(e.target.value)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
            />
          </div>

          <div className="sm:col-span-2">
            <button
              id="btn-add-blocked-date"
              type="submit"
              disabled={adding}
              className="w-full py-2.5 px-4 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs disabled:opacity-50 cursor-pointer"
            >
              {adding ? 'Saving...' : 'Block Date'}
            </button>
          </div>
        </form>
      </div>

      {/* Blocked Dates List */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
            Currently Blocked Dates ({blockedDates.length})
          </span>
          <span className="text-[11px] text-slate-400">Blocked dates are instantly excluded from public slots</span>
        </div>

        {blockedDates.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-xs">
            No dates are currently blocked. The public calendar follows standard weekly operating hours.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {blockedDates.map((item) => (
              <div key={item.id} className="p-4 flex items-center justify-between hover:bg-slate-50/60 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
                    <CalendarX className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 text-xs block">
                      {formatDateForDisplay(item.blocked_date)}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {item.blocked_date} • {item.reason || 'Closed'}
                    </span>
                  </div>
                </div>

                <button
                  id={`remove-blocked-${item.id}`}
                  onClick={() => handleDeleteBlockedDate(item.id)}
                  className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                  title="Unblock Date"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
