import React from 'react';
import { Sparkles, Phone, Mail, MapPin, Clock, ShieldCheck, Heart } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';

export const Footer: React.FC = () => {
  const { settings, businessHours } = useClinic();

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800" id="main-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Col 1: Brand & Care statement */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-500 to-cyan-400 flex items-center justify-center text-slate-950 shadow-md">
                <Sparkles className="w-5 h-5 text-slate-950" />
              </div>
              <div>
                <span className="font-extrabold text-white text-lg tracking-tight block">
                  {settings.clinic_name}
                </span>
                <span className="text-[10px] tracking-wider uppercase text-teal-400 font-semibold">
                  Modern Smile Care
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Dedicated to compassionate, anxiety-free dentistry. We blend modern clinical precision
              with genuine patient warmth to keep your smile healthy, natural, and radiant.
            </p>
            <div className="pt-2 flex items-center gap-2 text-[11px] text-slate-400">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <span>Strict Hospital-Grade Sterilization Protocols</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Quick Navigation</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#services" className="hover:text-teal-400 transition-colors">
                  Dental Services &amp; Fees
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-teal-400 transition-colors">
                  About Our Clinic &amp; Doctors
                </a>
              </li>
              <li>
                <a href="#experience" className="hover:text-teal-400 transition-colors">
                  The Patient Experience
                </a>
              </li>
              <li>
                <a href="#hours" className="hover:text-teal-400 transition-colors">
                  Office Hours &amp; Directions
                </a>
              </li>
              <li>
                <a href="#booking" className="hover:text-teal-400 transition-colors font-medium text-teal-300">
                  Book Online Appointment
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact Details */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Clinic Information</h4>
            <ul className="space-y-3 text-xs">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-teal-400 flex-shrink-0 mt-0.5" />
                <span className="text-slate-300">{settings.clinic_address}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-teal-400 flex-shrink-0" />
                <a href={`tel:${settings.clinic_phone}`} className="hover:text-teal-400 transition-colors">
                  {settings.clinic_phone}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-teal-400 flex-shrink-0" />
                <a href={`mailto:${settings.clinic_email}`} className="hover:text-teal-400 transition-colors">
                  {settings.clinic_email}
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Hours Snapshot */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Clock className="w-4 h-4 text-teal-400" />
              Hours of Care
            </h4>
            <div className="text-xs space-y-1.5 text-slate-300">
              <p className="flex justify-between border-b border-slate-800 pb-1">
                <span>Mon – Thu:</span>
                <span className="font-mono text-slate-400">9:00 AM – 6:00 PM</span>
              </p>
              <p className="flex justify-between border-b border-slate-800 pb-1">
                <span>Friday:</span>
                <span className="font-mono text-slate-400">9:00 AM – 5:00 PM</span>
              </p>
              <p className="flex justify-between border-b border-slate-800 pb-1">
                <span>Saturday:</span>
                <span className="font-mono text-slate-400">10:00 AM – 3:00 PM</span>
              </p>
              <p className="flex justify-between text-slate-500">
                <span>Sunday:</span>
                <span>Closed (Emergency on call)</span>
              </p>
            </div>
            <div className="pt-2">
              <a
                href="/admin/login"
                className="inline-flex items-center gap-1.5 text-[11px] text-slate-400 hover:text-white transition-colors bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/60"
                id="footer-admin-login-link"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
                Clinic Admin &amp; Staff Login
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} {settings.clinic_name}. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Built with modern precision for comprehensive patient oral health &amp; comfort.
          </p>
        </div>
      </div>
    </footer>
  );
};
