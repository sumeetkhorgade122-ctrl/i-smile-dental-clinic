import React, { useState, useEffect } from 'react';
import { Phone, Calendar, Menu, X, Clock, ShieldCheck, Sparkles } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';

interface NavbarProps {
  onBookClick?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onBookClick }) => {
  const { settings } = useClinic();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleBookingAction = () => {
    setMobileMenuOpen(false);
    if (onBookClick) {
      onBookClick();
    } else {
      const el = document.getElementById('booking');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-100 py-3'
          : 'bg-white/80 backdrop-blur-sm border-b border-slate-100/60 py-4'
      }`}
      id="main-navbar"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Clinic Brand */}
          <a
            href="/"
            className="flex items-center gap-3 group focus:outline-none focus:ring-2 focus:ring-teal-500 rounded-xl"
            id="nav-brand-link"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-700 via-teal-600 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-teal-700/20 group-hover:scale-105 transition-transform duration-200">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-extrabold text-slate-900 tracking-tight text-lg sm:text-xl block leading-tight font-sans">
                {settings.clinic_name}
              </span>
              <span className="text-[10px] tracking-widest uppercase font-semibold text-teal-700 block">
                Modern Smile Care &amp; Dentistry
              </span>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2 text-sm font-medium text-slate-600">
            <a
              href="#services"
              className="px-3.5 py-2 rounded-lg hover:text-teal-700 hover:bg-slate-50 transition-colors"
              id="nav-link-services"
            >
              Services
            </a>
            <a
              href="#about"
              className="px-3.5 py-2 rounded-lg hover:text-teal-700 hover:bg-slate-50 transition-colors"
              id="nav-link-about"
            >
              About
            </a>
            <a
              href="#experience"
              className="px-3.5 py-2 rounded-lg hover:text-teal-700 hover:bg-slate-50 transition-colors"
              id="nav-link-experience"
            >
              Patient Care
            </a>
            <a
              href="#hours"
              className="px-3.5 py-2 rounded-lg hover:text-teal-700 hover:bg-slate-50 transition-colors"
              id="nav-link-hours"
            >
              Hours &amp; Location
            </a>
          </nav>

          {/* Right Action CTA & Phone */}
          <div className="hidden sm:flex items-center gap-4">
            <a
              href={`tel:${settings.clinic_phone}`}
              className="flex items-center gap-2 text-xs font-semibold text-slate-700 hover:text-teal-700 px-3 py-2 rounded-lg hover:bg-teal-50/60 transition-colors border border-slate-200/80"
              id="nav-phone-call"
            >
              <Phone className="w-3.5 h-3.5 text-teal-600" />
              <span>{settings.clinic_phone}</span>
            </a>

            <button
              id="nav-book-appointment-btn"
              onClick={handleBookingAction}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-teal-700 to-teal-600 hover:from-teal-800 hover:to-teal-700 text-white font-semibold text-sm px-5 py-2.5 rounded-xl shadow-md shadow-teal-700/20 hover:shadow-lg hover:shadow-teal-700/30 transition-all duration-200 cursor-pointer active:scale-95"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Appointment</span>
            </button>
          </div>

          {/* Mobile Menu Toggle Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              id="mobile-book-shortcut"
              onClick={handleBookingAction}
              className="bg-teal-700 text-white p-2 rounded-lg shadow-sm text-xs font-semibold flex items-center gap-1"
            >
              <Calendar className="w-4 h-4" />
            </button>
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 hover:text-teal-700 hover:bg-slate-100 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500"
              aria-label="Toggle navigation menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div
          className="md:hidden bg-white border-b border-slate-200 shadow-xl px-4 pt-3 pb-6 space-y-3 animate-in slide-in-from-top-2"
          id="mobile-nav-menu"
        >
          <div className="flex flex-col space-y-1 pt-2">
            <a
              href="#services"
              onClick={() => setMobileMenuOpen(false)}
              className="px-4 py-2.5 rounded-lg text-slate-700 hover:bg-teal-50 hover:text-teal-700 font-medium text-sm transition-colors"
            >
              Dental Services
            </a>
            <a
              href="#about"
              onClick={() => setMobileMenuOpen(false)}
              className="px-4 py-2.5 rounded-lg text-slate-700 hover:bg-teal-50 hover:text-teal-700 font-medium text-sm transition-colors"
            >
              About the Clinic
            </a>
            <a
              href="#experience"
              onClick={() => setMobileMenuOpen(false)}
              className="px-4 py-2.5 rounded-lg text-slate-700 hover:bg-teal-50 hover:text-teal-700 font-medium text-sm transition-colors"
            >
              Patient Experience
            </a>
            <a
              href="#hours"
              onClick={() => setMobileMenuOpen(false)}
              className="px-4 py-2.5 rounded-lg text-slate-700 hover:bg-teal-50 hover:text-teal-700 font-medium text-sm transition-colors"
            >
              Hours &amp; Location
            </a>
            <a
              href="/admin/login"
              onClick={() => setMobileMenuOpen(false)}
              className="px-4 py-2.5 rounded-lg text-slate-500 hover:bg-slate-100 font-medium text-xs flex items-center justify-between"
            >
              <span>Clinic Staff Login</span>
              <ShieldCheck className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-2">
            <a
              href={`tel:${settings.clinic_phone}`}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
            >
              <Phone className="w-3.5 h-3.5 text-teal-600" />
              <span>Call Clinic: {settings.clinic_phone}</span>
            </a>
            <button
              onClick={handleBookingAction}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-teal-700 text-white font-semibold rounded-xl text-sm shadow-md active:scale-95 transition-all"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Appointment Now</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
