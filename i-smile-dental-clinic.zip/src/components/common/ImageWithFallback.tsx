import React, { useState } from 'react';
import { Sparkles } from 'lucide-react';

interface ImageWithFallbackProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackText?: string;
}

export const ImageWithFallback: React.FC<ImageWithFallbackProps> = ({
  src,
  alt,
  className = '',
  fallbackText = 'I Smile Dental Clinic',
  ...props
}) => {
  const [error, setError] = useState(false);

  if (error || !src) {
    return (
      <div
        className={`bg-gradient-to-br from-slate-100 via-teal-50/50 to-slate-200 flex flex-col items-center justify-center text-slate-400 p-6 ${className}`}
        role="img"
        aria-label={alt || fallbackText}
      >
        <div className="w-12 h-12 rounded-full bg-teal-100/80 flex items-center justify-center text-teal-600 mb-2">
          <Sparkles className="w-6 h-6" />
        </div>
        <p className="text-xs font-medium text-slate-500 text-center">{fallbackText}</p>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt || 'Dental Clinic care'}
      className={`object-cover ${className}`}
      onError={() => setError(true)}
      loading="lazy"
      referrerPolicy="no-referrer"
      {...props}
    />
  );
};
