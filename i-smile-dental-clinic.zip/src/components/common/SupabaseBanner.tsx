import React, { useEffect, useState } from 'react';
import {
  Database,
  CheckCircle2,
  Copy,
  Check,
  ExternalLink,
  ShieldAlert,
  Link2,
  Key,
  Globe,
  Trash2,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import {
  isSupabaseConfigured,
  activeSupabaseUrl,
  activeSupabaseAnonKey,
  setCustomSupabaseCredentials,
  clearCustomSupabaseCredentials,
  testSupabaseConnection,
} from '../../lib/supabase';
import { SUPABASE_SQL_SCHEMA } from '../../data/supabaseSchema';
import { Modal } from './Modal';
import { clinicService } from '../../services/clinicService';

export const SupabaseBanner: React.FC = () => {
  const [showModal, setShowModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'connect' | 'sql'>('connect');
  const [copied, setCopied] = useState(false);
  const [seedLoading, setSeedLoading] = useState(false);
  const [seedMessage, setSeedMessage] = useState<string | null>(null);

  // Live reachability state
  const [connectionState, setConnectionState] = useState<
    'not_configured' | 'checking' | 'connected' | 'unreachable'
  >(isSupabaseConfigured ? 'checking' : 'not_configured');
  const [connectionWarning, setConnectionWarning] = useState<string | null>(null);

  // Connection form state
  const [inputUrl, setInputUrl] = useState(activeSupabaseUrl || '');
  const [inputKey, setInputKey] = useState(activeSupabaseAnonKey || '');
  const [connectError, setConnectError] = useState<string | null>(null);
  const [savingCredentials, setSavingCredentials] = useState(false);

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setConnectionState('not_configured');
      return;
    }

    let isMounted = true;
    testSupabaseConnection(activeSupabaseUrl, activeSupabaseAnonKey).then((result) => {
      if (!isMounted) return;
      if (result.ok) {
        setConnectionState('connected');
        setConnectionWarning(null);
      } else {
        setConnectionState('unreachable');
        setConnectionWarning(
          result.error || 'Configured Supabase URL could not be reached. Using local fallback.'
        );
      }
    });

    return () => {
      isMounted = false;
    };
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSeed = async () => {
    setSeedLoading(true);
    setSeedMessage(null);
    const result = await clinicService.seedInitialData();
    setSeedLoading(false);
    setSeedMessage(result.message);
  };

  const handleSaveConnection = async (e: React.FormEvent) => {
    e.preventDefault();
    setConnectError(null);

    const cleanUrl = inputUrl.trim();
    const cleanKey = inputKey.trim();

    if (!cleanUrl || !cleanKey) {
      setConnectError('Both Project URL and Anon API Key are required.');
      return;
    }

    setSavingCredentials(true);
    try {
      const check = await testSupabaseConnection(cleanUrl, cleanKey);
      if (!check.ok) {
        setConnectError(check.error || 'Could not verify Supabase connection.');
        setSavingCredentials(false);
        return;
      }

      setCustomSupabaseCredentials(check.normalizedUrl, cleanKey);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to verify credentials';
      setConnectError(msg);
      setSavingCredentials(false);
    }
  };

  const handleDisconnect = () => {
    clearCustomSupabaseCredentials();
  };

  const dotColor =
    connectionState === 'connected'
      ? 'bg-emerald-400 animate-pulse'
      : connectionState === 'unreachable'
      ? 'bg-rose-400'
      : 'bg-amber-400';

  const statusLabel =
    connectionState === 'connected' ? (
      <span className="text-emerald-300 font-bold">Supabase Live Connected</span>
    ) : connectionState === 'checking' ? (
      <span className="text-slate-300 font-bold">Checking Supabase Connection...</span>
    ) : connectionState === 'unreachable' ? (
      <span className="text-rose-300 font-bold">Supabase Unreachable (Local Mode)</span>
    ) : (
      <span className="text-amber-300 font-bold">Supabase Not Connected</span>
    );

  return (
    <>
      {/* Persistent Banner */}
      <div className="bg-slate-950 text-slate-200 text-xs py-2 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2.5">
          <div className="flex items-center gap-2.5">
            <span className={`w-2.5 h-2.5 rounded-full ${dotColor}`} />
            <span className="font-semibold tracking-tight">{statusLabel}</span>
            <span className="hidden sm:inline text-slate-400 text-[11px]">
              {connectionState === 'connected'
                ? `Project: ${activeSupabaseUrl.replace(/^https?:\/\//, '').split('.')[0] || 'Active'}`
                : connectionState === 'unreachable'
                ? 'Bookings are saved locally until your Supabase URL is reachable'
                : 'Connect your project to enable live database & auth'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              id="btn-connect-supabase-top"
              onClick={() => {
                setActiveTab('connect');
                setShowModal(true);
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                connectionState === 'connected'
                  ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  : connectionState === 'unreachable'
                  ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-sm'
                  : 'bg-teal-600 hover:bg-teal-500 text-white shadow-sm'
              }`}
            >
              <Link2 className="w-3.5 h-3.5" />
              <span>
                {connectionState === 'connected'
                  ? 'Connection Settings'
                  : connectionState === 'unreachable'
                  ? 'Fix Connection'
                  : 'Connect to Supabase'}
              </span>
            </button>

            <button
              id="btn-view-supabase-sql"
              onClick={() => {
                setActiveTab('sql');
                setShowModal(true);
              }}
              className="text-slate-400 hover:text-teal-300 underline font-medium flex items-center gap-1 cursor-pointer"
            >
              <Database className="w-3.5 h-3.5" />
              <span>SQL Schema</span>
            </button>

            <a
              href="/admin/login"
              className="text-slate-300 hover:text-white transition-colors underline"
            >
              Admin Portal
            </a>
          </div>
        </div>
      </div>

      {/* Modal Dialog */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title="Supabase Database Connection & Setup"
        subtitle="Connect your Supabase project to power live dental appointments, scheduling, and clinic auth."
        maxWidth="max-w-3xl"
      >
        <div className="space-y-5">
          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <button
              id="tab-connect"
              onClick={() => setActiveTab('connect')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'connect'
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              <Link2 className="w-3.5 h-3.5" />
              <span>1. Project Credentials</span>
            </button>

            <button
              id="tab-sql-schema"
              onClick={() => setActiveTab('sql')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'sql'
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>2. Database Tables &amp; SQL Schema</span>
            </button>
          </div>

          {/* TAB 1: Credentials & Connection Form */}
          {activeTab === 'connect' && (
            <div className="space-y-5">
              {/* Status Header */}
              <div
                className={`p-4 rounded-2xl border flex items-center justify-between flex-wrap gap-3 ${
                  connectionState === 'connected'
                    ? 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
                    : connectionState === 'unreachable'
                    ? 'bg-rose-50/80 border-rose-200 text-rose-900'
                    : 'bg-amber-50/80 border-amber-200 text-amber-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                      connectionState === 'connected'
                        ? 'bg-emerald-600 text-white'
                        : connectionState === 'unreachable'
                        ? 'bg-rose-600 text-white'
                        : 'bg-amber-500 text-white'
                    }`}
                  >
                    <Globe className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider">
                      {connectionState === 'connected'
                        ? 'Connected to Supabase Project'
                        : connectionState === 'unreachable'
                        ? 'Saved Supabase Project Is Unreachable'
                        : 'No Active Connection'}
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5 font-mono">
                      {isSupabaseConfigured
                        ? activeSupabaseUrl
                        : 'Provide your Project URL & Anon Key below to establish connection'}
                    </p>
                  </div>
                </div>

                {isSupabaseConfigured && (
                  <button
                    type="button"
                    onClick={handleDisconnect}
                    className="px-3 py-1.5 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Disconnect</span>
                  </button>
                )}
              </div>

              {connectionWarning && connectionState === 'unreachable' && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                  <span>{connectionWarning}</span>
                </div>
              )}

              {/* Step-by-step how to get keys */}
              <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-2xl text-xs text-slate-700 space-y-2">
                <div className="flex items-center gap-2 font-bold text-slate-900">
                  <Key className="w-4 h-4 text-teal-600" />
                  <span>Where to find your Supabase credentials:</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-slate-600 text-[11px] leading-relaxed pl-1">
                  <li>
                    Open your{' '}
                    <a
                      href="https://supabase.com/dashboard"
                      target="_blank"
                      rel="noreferrer"
                      className="text-teal-700 font-semibold underline inline-flex items-center gap-0.5"
                    >
                      Supabase Dashboard <ExternalLink className="w-3 h-3 inline" />
                    </a>{' '}
                    and select your project.
                  </li>
                  <li>
                    Navigate to <strong className="text-slate-800">Project Settings</strong> (gear icon in sidebar) &rarr; <strong className="text-slate-800">API</strong>.
                  </li>
                  <li>
                    Copy your <strong className="text-slate-800">Project URL</strong> (e.g., <code className="bg-slate-200 px-1 py-0.5 rounded font-mono">https://xyzcompany.supabase.co</code>).
                  </li>
                  <li>
                    Copy your <strong className="text-slate-800">`anon` `public` API Key</strong>.
                  </li>
                </ol>
              </div>

              {connectError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                  <span>{connectError}</span>
                </div>
              )}

              {/* Form to paste/save credentials */}
              <form onSubmit={handleSaveConnection} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Supabase Project URL <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Globe className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="url"
                      required
                      value={inputUrl}
                      onChange={(e) => setInputUrl(e.target.value)}
                      placeholder="https://your-project-id.supabase.co"
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Supabase Anon Public Key (anon public) <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Key className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      required
                      value={inputKey}
                      onChange={(e) => setInputKey(e.target.value)}
                      placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 font-mono"
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between flex-wrap gap-2">
                  <p className="text-[11px] text-slate-500">
                    Connection is verified before saving to your browser session.
                  </p>
                  <button
                    id="btn-save-supabase-connection"
                    type="submit"
                    disabled={savingCredentials}
                    className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer disabled:opacity-50 flex items-center gap-2"
                  >
                    {savingCredentials ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Verifying Connection...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Verify &amp; Connect to Supabase</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 2: SQL Schema & Seed Migration */}
          {activeTab === 'sql' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-semibold text-slate-700">Tables:</span>
                  <span className="text-[11px] bg-teal-100 text-teal-800 px-2 py-0.5 rounded font-mono">services</span>
                  <span className="text-[11px] bg-teal-100 text-teal-800 px-2 py-0.5 rounded font-mono">appointments</span>
                  <span className="text-[11px] bg-teal-100 text-teal-800 px-2 py-0.5 rounded font-mono">business_hours</span>
                  <span className="text-[11px] bg-teal-100 text-teal-800 px-2 py-0.5 rounded font-mono">blocked_dates</span>
                  <span className="text-[11px] bg-teal-100 text-teal-800 px-2 py-0.5 rounded font-mono">clinic_settings</span>
                  <span className="text-[11px] bg-teal-100 text-teal-800 px-2 py-0.5 rounded font-mono">admin_users</span>
                </div>
                <button
                  id="copy-sql-btn"
                  onClick={handleCopy}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-medium transition-all shadow-sm cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-white" />
                      Copied SQL
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copy SQL Script
                    </>
                  )}
                </button>
              </div>

              <div className="relative">
                <pre className="bg-slate-900 text-slate-200 p-4 rounded-xl text-xs font-mono max-h-72 overflow-y-auto leading-relaxed selection:bg-teal-500 selection:text-white">
                  {SUPABASE_SQL_SCHEMA}
                </pre>
              </div>

              {connectionState === 'connected' && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                      <p className="text-xs text-emerald-900 font-medium">
                        Credentials active! If you ran the table creation without initial data, click to seed default clinic values.
                      </p>
                    </div>
                    <button
                      id="seed-supabase-btn"
                      onClick={handleSeed}
                      disabled={seedLoading}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-medium transition-colors disabled:opacity-50 cursor-pointer"
                    >
                      {seedLoading ? 'Seeding Data...' : 'Seed Initial Clinic Data'}
                    </button>
                  </div>
                  {seedMessage && (
                    <p className="text-xs text-emerald-800 mt-2 font-medium bg-white/70 p-2 rounded border border-emerald-100">
                      {seedMessage}
                    </p>
                  )}
                </div>
              )}

              <div className="bg-amber-50 border border-amber-200 p-3.5 rounded-xl flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-xs text-amber-900 space-y-1">
                  <p className="font-semibold">How Admin Authorization Works:</p>
                  <p>
                    When an administrator signs in with email/password via Supabase Auth, their <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">user.id</code> is verified against <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">admin_users.user_id</code>.
                    To designate an admin, create an account in Supabase Auth, copy the User UID, and insert it into <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">admin_users</code>:
                  </p>
                  <code className="block bg-amber-100/80 p-1.5 rounded font-mono text-[11px] select-all">
                    INSERT INTO public.admin_users (user_id) VALUES (&apos;PASTE_AUTH_USER_UUID_HERE&apos;);
                  </code>
                </div>
              </div>
            </div>
          )}
        </div>
      </Modal>
    </>
  );
};
